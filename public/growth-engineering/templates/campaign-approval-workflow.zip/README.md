# Ship AI · campaign-approval-workflow

A reusable agency template with fictional Desert Shine reference output. Unzip into one folder; preserve its structure. Requires Node 20+ and npm. Read `BUILD-YOUR-AI-MARKETING-TEAM.md`, then `templates/campaign-approval-workflow/README.md` and `SKILL.md`. The full workflow sequences the site, static feedback loop, Facebook ad research, video feedback loop, and exact-destination Zernio handoff. `<kit-root>` means the extracted folder.

Run from kit root:
```bash
node templates/campaign-approval-workflow/template/build-review-bundle.mjs --project . --client desert-shine --media templates/campaign-approval-workflow/example/desert-shine-redesign/media --items social-v1,video-v1 --out runs/desert-shine --outbox runs/desert-shine/outbox --copy-media --version v1 && node --test templates/campaign-approval-workflow/template/build-review-bundle.test.mjs
```

The workflow exports local NOT_SENT requests and remains unapproved. It has no network sender. The website quote form is demo-only. Full kit and bot imports: https://www.shipai.club/programs/zero-to-launch/growth-engineering/deck
