# Ship AI · client-website

A reusable agency template with fictional Desert Shine reference output. Unzip into one folder; preserve its structure. Requires Node 20+ and npm. Read `BUILD-YOUR-AI-MARKETING-TEAM.md`, then `templates/client-website/README.md` and `SKILL.md`. The full workflow sequences the site, static feedback loop, Facebook ad research, video feedback loop, and exact-destination Zernio handoff. `<kit-root>` means the extracted folder.

Run from kit root:
```bash
cd templates/client-website/template && npm ci && CLIENTS_DIR=../../../clients ASSETS_DIR=../../../assets NEXT_PUBLIC_CLIENT=desert-shine npm run build && CLIENTS_DIR=../../../clients ASSETS_DIR=../../../assets NEXT_PUBLIC_CLIENT=desert-shine npm run start
```

The workflow exports local NOT_SENT requests and remains unapproved. It has no network sender. The website quote form is demo-only. Full kit and bot imports: https://www.shipai.club/programs/zero-to-launch/growth-engineering/deck
