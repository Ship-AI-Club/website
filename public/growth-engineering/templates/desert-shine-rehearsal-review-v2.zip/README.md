# Ship AI agency starter kit

Four reusable templates built by the Ship AI demo bot team and rehearsed with **Desert Shine**, a fictional Phoenix housecleaning client. Unzip into one folder. `<kit-root>` means that folder (Grok Bot demo: `/workspace/ship-ai-demo/`). Commands below start at the kit root. Requires Node 20+ and npm; approval checks also use bash.

## Start with the bots

- [Site Builder](https://x.ai/bot/ksd6wk5e84h2BvKm7riaq): website and shared client brief.
- [Creative Studio](https://x.ai/bot/js3Rh17IRwiUhXlkySUg5): social graphics and short video.
- [Campaign Manager](https://x.ai/bot/5rgMPM-0FpH1ZflzjNDk1): handoffs, review, and exact-version approval.

Import the bots into your Ship AI group and ask each to read its template README and SKILL.md. Start with “Use the Desert Shine example in dry run.” The import templates download this kit on first use.

## One approved input

`clients/<slug>/brand.json` and `content.json` hold the brand, services, CTA, website copy, captions, and video text. Add a client by copying `clients/_template/` into `clients/<slug>/` and filling supplied facts. Keep unknown facts null. Never invent reviews, prices, credentials, insurance, or results.

### 1. Website · Site Builder

```bash
cd templates/client-website/template
npm ci
CLIENTS_DIR=../../../clients NEXT_PUBLIC_CLIENT=desert-shine npm run build
CLIENTS_DIR=../../../clients NEXT_PUBLIC_CLIENT=desert-shine npm run start
```

Open localhost:3000 and /quote. The form is a labeled demo. Capture both pages as `out/site-snapshot.png` and `out/site-quote.png` at kit root. Full-kit campaigns must set CLIENTS_DIR (as above) so the site reads the root `clients/<slug>/` record directly; do not sync or copy client JSON into the template. Only a standalone website download omits CLIENTS_DIR and uses its bundled `template/clients/`.

### 2. Social graphics · Creative Studio

From kit root:
```bash
cd remotion
npm ci
node ../templates/social-graphics/template/render-stills.mjs --client desert-shine
```

Renders three 1080×1350 PNGs plus square variants into `out/`. Remotion installs its headless browser on first render.

### 3. Short video · Creative Studio

From kit root after installing Remotion:
```bash
cd remotion
node ../templates/short-video/template/render-reel.mjs --client desert-shine
```

Renders a 15-second 1080×1920 MP4 into `out/`. Inspect the complete video before review.

### 4. Campaign review · Campaign Manager

From kit root, rehearse with the included reference media:
```bash
node templates/campaign-approval-workflow/template/build-review-bundle.mjs --project . --client desert-shine --media templates/campaign-approval-workflow/example/desert-shine/media --out runs/desert-shine --outbox runs/desert-shine/outbox --copy-media --version v1
bash templates/campaign-approval-workflow/template/approval-test.sh runs/desert-shine/bundle.json
```

For freshly rendered assets, replace the `--media` argument with `out`. Review `runs/desert-shine/review-bundle.html`. The test uses a temporary copy and rejects unapproved versions, changed captions, changed destinations, and missing media. The exported bundle remains unapproved.

## What is included

Each `templates/<name>/` has editable source, README, SKILL.md, and a Desert Shine example. `template-manifest.json` lists inputs, outputs, and commands. Individual template downloads preserve this directory structure and include their dependencies.

This kit saves **local NOT_SENT request previews**. It has no Zernio credentials or network sender. The disabled routine is a later starting point. A real handoff needs the client's connected accounts, owner approval of the exact bundle, server-side credentials, and a verified draft response. Scheduling or publishing is a separate decision. [Zernio quickstart](https://docs.zernio.com/) · [Media uploads](https://docs.zernio.com/guides/media-uploads).
