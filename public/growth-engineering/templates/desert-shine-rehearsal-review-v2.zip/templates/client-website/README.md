# Client Website: starter template (Ship AI Demo kit)

Generic, self-contained Next.js (App Router) marketing site: home page (hero + CTA, services, service area, FAQ, footer) and a demo-only `/quote` form. The pages contain no hardcoded business copy. All copy and tokens come from `template/clients/<client>/brand.json` and `content.json`, read at build time by `template/lib/client.ts`. Node scripts can read the same files with `template/clients/load.mjs`.

## Inputs
| Input | Where | Notes |
|---|---|---|
| Client slug | `NEXT_PUBLIC_CLIENT` env var (default `_template`, the placeholder client) | `a-z0-9_-` |
| `brand.json` | `template/clients/<client>/brand.json` | client meta, business name, CTA, tokens (colors, font, radius) |
| `content.json` | `template/clients/<client>/content.json` | tagline, CTA, services, service area, FAQ, `unset` (null = keep out of copy), social/reel copy, site meta/footer/quote note |

Dependencies: Node 18.18+ and npm (versions pinned in `package-lock.json`). Nothing outside `template/` is needed.

## Outputs
- `.next/` production build plus a local preview at `http://localhost:<PORT>` (default 3000)
- Screenshots for the campaign bundle (headless Chromium/Playwright): `out/site-snapshot.png` (home page) and `out/site-quote.png` (`/quote`)
- Reference output: `example/desert-shine/`

## Add a client
1. Standalone only: `cp -r template/clients/_template template/clients/<client>`. In the full kit, add the client under root `clients/<client>/` and use `CLIENTS_DIR` (no copy).
2. Fill in both JSON files from supplied facts only. Never invent prices, testimonials, licenses, insurance, discounts or contact details. Leave unknowns `null` under `unset`.
3. No registry to edit: the folder name is the slug.

## Run (one command, from `template/`; set `CLIENT` and `PORT`)
```bash
CLIENT=desert-shine PORT=3000; npm ci && NEXT_PUBLIC_CLIENT=$CLIENT npx next build && NEXT_PUBLIC_CLIENT=$CLIENT npx next start -p $PORT
```

The quote form stays demo-only (no submit target) unless the owner approves a real handler. No deploys without explicit approval. See `SKILL.md`.

## Shared kit input
**Full starter kit (default for campaign runs):** always set `CLIENTS_DIR=../../../clients` on both build and start so the website reads the single root `clients/<client>/` record shared with Remotion and Campaign Manager. Do **not** copy or sync root client JSON into `template/clients/`; duplicate copies drift. `template/lib/client.ts` resolves `CLIENTS_DIR` (else `template/clients/`) at build time.

```bash
cd templates/client-website/template && npm ci
CLIENTS_DIR=../../../clients NEXT_PUBLIC_CLIENT=desert-shine npm run build
CLIENTS_DIR=../../../clients NEXT_PUBLIC_CLIENT=desert-shine npm run start -- -p 3000
```

Standalone use only (template downloaded alone): omit `CLIENTS_DIR` and it reads the bundled `template/clients/` folder.
