// Self-contained client loader. Reads clients/<slug>/brand.json + content.json at build time.
// Slug comes from NEXT_PUBLIC_CLIENT (default "_template"). Adding a client = adding a folder; no registry.
import fs from "node:fs";
import path from "node:path";
import type brandShape from "../clients/_template/brand.json";
import type contentShape from "../clients/_template/content.json";
export type Brand = typeof brandShape;
export type Content = typeof contentShape;
export const CLIENT = process.env.NEXT_PUBLIC_CLIENT || "_template";
function load(id: string): { brand: Brand; content: Content } {
  if (!/^[a-z0-9_-]+$/.test(id)) throw new Error(`Invalid client slug "${id}"`);
  const clientsDir = path.resolve(process.env.CLIENTS_DIR || path.join(process.cwd(), "clients"));
  const dir = path.join(clientsDir, id);
  if (!fs.existsSync(dir)) throw new Error(`Unknown client "${id}": expected ${dir}/brand.json and content.json`);
  const read = (f: string) => JSON.parse(fs.readFileSync(path.join(dir, f), "utf8"));
  return { brand: read("brand.json"), content: read("content.json") };
}
export const { brand, content } = load(CLIENT);
