# Ship AI agency templates · 1.2.0

Practical AI, Built Together.

A four-role marketing team, with Site Builder as a separate website setup specialist. These are the actual bot-authored source templates used to rebuild Desert Shine, our fictional Phoenix housecleaning client. Unzip into one folder, then read `BUILD-YOUR-AI-MARKETING-TEAM.md`. Node 20+ and npm required. Commands below begin at kit root.

## Get the team

- [Social Media Manager](https://x.ai/bot/5rgMPM-0FpH1ZflzjNDk1)
- [Performance Marketer](https://x.ai/bot/WQpbnRwh4H-DArkEBQCK5)
- [Content Creator · Design](https://x.ai/bot/js3Rh17IRwiUhXlkySUg5)
- [Content Creator · Video](https://x.ai/bot/Td8xsp1w2slejHsx62m0y)
- [Site Builder](https://x.ai/bot/ksd6wk5e84h2BvKm7riaq): website setup specialist

Bot imports carry instructions and skills; this kit carries runnable source, client JSON, photos, SVGs and font licenses. The actual exported role skills and onboarding live in `bot-roles/`.

## One sequenced workflow

1. Build the marketing site and review desktop, mobile and the quote flow.
2. Render one static creative; repeat feedback until approved.
3. Performance Marketer researches Meta ads and briefs the Video Creator. Approve the storyboard.
4. Render and review the entire video; revise until its exact file is approved.
5. Social Media Manager assembles captions, selected files and the exact Zernio account in one versioned bundle.
6. Only after handoff approval, use the configured Zernio integration to create drafts and read back their status.

Use Zernio for social drafts and Meta Ads MCP for paid-ad reporting and analysis. Both connections are currently planned, not verified in this demo; see `bot-roles/INTEGRATIONS.md`. No campaign launch or budget changes are part of this rehearsal. Generation remains model agnostic.

## Shared client inputs

`clients/<slug>/brand.json` and `content.json` are canonical for every template. `assets/` contains licensed photos, logos and icons. Unknown facts stay null. Copy `clients/_template/` for a new client and replace supplied facts/assets before building; do not invent reviews, prices, staff or guarantees.

## client-website

Read `templates/client-website/README.md` and `SKILL.md`.

```bash
cd templates/client-website/template && npm ci && CLIENTS_DIR=../../../clients ASSETS_DIR=../../../assets NEXT_PUBLIC_CLIENT=desert-shine npm run build && CLIENTS_DIR=../../../clients ASSETS_DIR=../../../assets NEXT_PUBLIC_CLIENT=desert-shine npm run start
```

## social-graphics

Read `templates/social-graphics/README.md` and `SKILL.md`.

```bash
cd templates/social-graphics/template && npm ci && node render-creative.mjs --project ../../.. --remotion . --client desert-shine --id social-v1 --out ../../../out --name social-v1.png
```

## short-video

Read `templates/short-video/README.md` and `SKILL.md`.

```bash
cd templates/short-video/template && npm ci && node render-reel.mjs --clients ../../../clients --assets ../../../assets --client desert-shine --reel video-v1 --out ../../../out --name video-v1.mp4
```

## campaign-approval-workflow

Read `templates/campaign-approval-workflow/README.md` and `SKILL.md`.

```bash
node templates/campaign-approval-workflow/template/build-review-bundle.mjs --project . --client desert-shine --media templates/campaign-approval-workflow/example/desert-shine-redesign/media --items social-v1,video-v1 --out runs/desert-shine --outbox runs/desert-shine/outbox --copy-media --version v1 && node --test templates/campaign-approval-workflow/template/build-review-bundle.test.mjs
```

The website quote form is a demo that prepares an on-page summary and sends nothing. For a static website export use the website command's environment variables with `npm run build:export`.

The current workflow reads `socialCreatives[]` and `video.reels[]`, preserving final captions. `--items social-v1` reviews only the first static; `--items social-v1,video-v1` includes both. Captures must be named `site-snapshot.png` and `site-quote.png` in the selected media folder. New renders use their own version and approval: browser/platform rasterization may change file hashes. The approved reference PNG/MP4 bytes are preserved in the current example.

The review builder has no network sender: its requests are local `NOT_SENT` previews. A real Zernio handoff requires verified account IDs, server-held credentials, exact-version approval, stable idempotency keys, returned draft IDs and readback. Public templates include no secrets, chat history, active routines or private client connections. Keep recurring automation off until the manual workflow works.

Current preview: `templates/campaign-approval-workflow/example/desert-shine-redesign/approval-review.html`. The older `example/desert-shine` is legacy evidence retained for regression checks; its media is not the current design. The public v2 archive stays unchanged.
