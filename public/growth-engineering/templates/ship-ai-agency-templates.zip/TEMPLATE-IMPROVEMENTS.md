# Ship AI template improvements

Practical AI, Built Together.

Our templates adapt public Grok Bot methods to a small agency serving a real client. The SpaceX Site Builder, loops, Critiquito and QA bot references are method references; these are our own Ship AI roles, source kit and client example. No upstream bot's private code, credentials or conversations are included.

## Reuse the complete sequence

Read `BUILD-YOUR-AI-MARKETING-TEAM.md`. Set up the three bots, build and review the site, create one static ad, repeat feedback and revisions, research video concepts, approve a storyboard, produce and refine the video, then review the exact destination before a Zernio handoff. `FACEBOOK-AD-RESEARCH.md` is a dated example; verify current references for the next client.

## Design and build acceptance

- Name the audience, positioning and primary action before designing.
- Create a specific palette, type system and photographic direction from the subject. Save actual local assets and a source/rights manifest.
- Use shared client files for business copy, design tokens and media references. Keep unsupported facts unset.
- Review desktop and mobile screenshots of the full page, not only the hero. Keep a dated critique and recheck the previous findings after a revision.
- Exercise the quote journey, including service selection, validation, confirmation and keyboard access. A fictional demo prepares a request and explicitly says nothing was sent.
- Test the production/static export and every local asset. Keep independent Next build directories or stop and restart the preview when changing build modes; one build must not overwrite the files used by a running preview.
- Check a second client record before calling the design reusable. Client copy, images and names must not leak between records.

## Creative review

A rendered file is a draft. Show the actual PNG or full video, ask one focused feedback question, record the answer, revise and show the new output. User approval identifies the exact version. Bot self-critique and silence are not user approval. Start with one static design before expanding variants.

Research Meta Ad Library and official guidance before proposing a video design. Record date, advertiser, ad ID and source URL where available. Explain observations and limitations. Do not turn an active ad into an unsupported performance claim or copy competitors' assets. Tie original concepts to the user's positioning, then get storyboard approval before production.

## Delivery

The bundled workflow scripts produce local NOT_SENT request previews and approval checks. They do not include a network sender or credentials. A configured bot/integration can perform the live handoff after exact-version approval: verify the specified client profile and account IDs, upload only selected media, create drafts by default, persist stable idempotency keys and returned IDs, then read back the remote status. A local request file is not proof of a remote draft. Do not confuse a social post with launching a paid ad campaign.

## Public method references

- https://x.ai/bot/s3c76c85a840b32b8fed8
- https://x.ai/bot/guides/templates-for-grok-bot
- https://x.ai/bot/Ub3T7usX-c6yRQibQq83P
- https://x.ai/bot/marketplace/bots/critiquito
- https://x.ai/bot/marketplace/bots/qa-bot
- https://docs.x.ai/grok-bot/skills-routines-and-automations
