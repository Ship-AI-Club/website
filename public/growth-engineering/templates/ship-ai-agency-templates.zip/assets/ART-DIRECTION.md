# Desert Shine — art direction
**Feel:** sunny, calm, editorial. Real warm light, lots of sky/white space, navy type. No gradients, overlays-with-gradients, emoji, badges or card grids.

## Crops & focal points (CSS object-position)
- hero-home.jpg (desktop 55% column): focal = central chimney + lit gable, ~45% x / 40% y → `object-position: 45% 40%`. Keep sky at top; never crop the chimney tops.
- hero-home-mobile.jpg (390px, 3:5): focal = chimney + window, `object-position: 50% 45%`. Copy sits above the image, not on it.
- hero-home-alt.jpg (ALT hero, 4:3, midday): focal = pergola entry + stone pillars, ~60% x / 58% y → `object-position: 60% 58%`. In a 55% column at 1440 keep the entry and the right-hand saguaro; crop sky first, never the roofline. Bright midday + deep blue sky sits naturally with navy/sky/sunflower tokens.
- hero-home-alt-mobile.jpg (390px, 3:5): focal = gate and pergola, ~45% x / 60% y → `object-position: 45% 60%`.
- services-living-room.jpg: focal sofa, `40% 60%`. services-open-plan.jpg: focal sofa/window, `50% 55%`. Use as one wide band (21:9) or a single side image, not three thumbnails.
- service-area-phoenix-aerial.jpg: focal horizon/mountains, `50% 35%`, 16:9 or 21:9. Desert-trail is the alternate.

## Treatment
- Full-colour, no filters, no duotone, no gradient scrims. Square corners or a single 4–8px radius site-wide.
- Text never sits on photos; if it must, use a solid navy #112B3C panel (white text) beside/below.
- Sunflower #FFCF4D only for small accents (sun disc, CTA fill with navy text, focus rings); sky #EAF4FF section backgrounds; slate #526777 body/secondary text on white (AA passes).
- Icons: 2.5px stroke, `currentColor` (navy), 40–48px, beside headings; no circles/tiles behind them.
- Use `<img>` / next/image with width/height set, `loading="eager"` + `fetchpriority="high"` on hero only.

## Type
Plus Jakarta Sans (OFL), self-hosted via `@fontsource/plus-jakarta-sans` (400, 600, 800). Headlines 800, tight tracking (-0.02em); body 400 at 18px/1.6. Fallback: system-ui. The lockup SVGs use live text in this font — inline them in the page (where the font is loaded) or convert to outlines before use as a standalone <img>.
