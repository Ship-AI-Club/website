# Desert Shine assets — sources & licenses
Photos: Pexels License (https://www.pexels.com/license/) — free commercial use, no attribution required; must not imply endorsement or be used as a trademark. Originals kept outside assets in ../_stock-originals/. All files downloaded locally; no hotlinking.

| File | Size | Source | License | Alt text |
|---|---|---|---|---|
| img/hero-home.jpg | 3200x2133 | https://www.pexels.com/photo/rustic-mediterranean-style-house-with-tile-roof-34960819/ (Robert So) — resized; small window sticker softened | Pexels License | Sunlit stucco home with red clay tile roof and tall chimneys against a blue sky |
| img/hero-home-mobile.jpg | 1200x2000 | Same photo, tall 3:5 crop | Pexels License | Sunlit stucco home with red clay tile roof and a tall chimney against a blue sky |
| img/hero-home-alt.jpg | 3264x2448 | https://pxhere.com/en/photo/372955 — full frame, retouched: removed house number plaque, "Central Alarm" yard sign + post, US flag, flagpole and halyard (LaMa inpainting for sky/sign/pole base, patch clone for pole across wall/pergola, Poisson clone for plaque). Script: ../_review/retouch.py | CC0 Public Domain (PxHere) | Pueblo-style stucco home with a pergola entry, saguaro, agave and a gravel desert yard under a bright blue sky |
| img/hero-home-alt-mobile.jpg | 1200x2000 | Same retouched photo, 3:5 crop (x 1198–2666 of 3264, full height), resized | CC0 Public Domain (PxHere) | Pueblo-style stucco home with a pergola entry, agave and a desert yard under a bright blue sky |
| img/services-living-room.jpg | 2400x1600 | https://www.pexels.com/photo/interior-of-a-modern-minimalist-living-room-19889112/ (Lisa Anna) | Pexels License | Bright, tidy living room with a white sectional sofa and light wood floors |
| img/services-open-plan.jpg | 2400x1601 | https://www.pexels.com/photo/bright-modern-living-room-interior-with-natural-light-36777853/ (Curtis Adams) | Pexels License | Clean open-plan living and dining area filled with natural light |
| img/service-area-phoenix-aerial.jpg | 2400x1350 | https://www.pexels.com/photo/aerial-view-of-suburban-arizona-landscape-34873752/ | Pexels License | Aerial view of a sunny Phoenix-area neighborhood with mountains on the horizon |
| img/service-area-desert-trail.jpg | 2400x1600 | https://www.pexels.com/photo/scenic-desert-landscape-in-phoenix-arizona-35528171/ | Pexels License | Sonoran desert boulders and palo verde trees under a blue Phoenix sky |
| brand/mark-navy.svg, brand/mark-white.svg | 64x64 vb | generated (bespoke) | Original work for client | "Desert Shine" (decorative next to text: alt="") |
| brand/lockup-navy.svg, brand/lockup-white.svg | 300x64 vb | generated (bespoke); text uses Plus Jakarta Sans 800 | Original; font OFL 1.1 | "Desert Shine" |
| icons/service-regular.svg | 48 vb | generated | Original | Regular cleaning (decorative beside heading: alt="") |
| icons/service-deep.svg | 48 vb | generated | Original | Deep cleaning |
| icons/service-move-out.svg | 48 vb | generated | Original | Move-out cleaning |
| icons/step-1-request.svg | 48 vb | generated | Original | Request a quote |
| icons/step-2-schedule.svg | 48 vb | generated | Original | Confirm your details and timing |
| icons/step-3-shine.svg | 48 vb | generated | Original | Come home to a clean house |
| brand/_preview-sheet.png | 800x520 | generated QA preview, not for site | — | — |

No people, staff, logos or badges appear in any photo.
