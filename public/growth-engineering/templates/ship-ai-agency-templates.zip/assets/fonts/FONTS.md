# Fonts
| File | Source | License |
|---|---|---|
| plus-jakarta-sans-latin-{400,600,800}-normal.woff2 | Plus Jakarta Sans (Tokotype) via @fontsource/plus-jakarta-sans 5.2.8 (https://fontsource.org/fonts/plus-jakarta-sans) | SIL OFL 1.1 (see LICENSE) |

The site self-hosts the font through the npm package, which Next bundles under `/_next/static/media`. These copies are for design use and reference. There are no CDN or runtime font requests.
