# Ship AI marketing team: integration map (kit 1.2)
Status as of 2026-10-14 15:28 PT. Both integrations are PLANNED and NOT VERIFIED.

The creative tools stay provider-agnostic: generation runs on local Remotion, licensed local assets and client JSON. Content Creator · Design and Content Creator · Video feed both managers.

| Role | Integration | Use | Writes allowed |
|---|---|---|---|
| Social Media Manager | Zernio | Upload approved media and create social DRAFTS for the exact approved bundle hash and named destination | Drafts only, after explicit approval. Publishing or scheduling needs a separate explicit ask naming the accounts. |
| Performance Marketer | Meta Ads MCP | Read-only account, campaign and ad reporting and analysis | None. No campaign launch, spend or budget change without the owner's explicit approval of that exact action. |
| Site Builder, Design, Video | none | Local build and render | n/a |

## Current state (read-only inspection)
- Zernio: no connector configured. Bundles stay local with NOT_SENT previews.
- Meta Ads MCP: a connector named `meta-ads` exists but fails tool discovery, so it is unusable until the owner reconnects it. Nothing was installed or granted.

## Minimal setup (owner does this)
1. Zernio: create an API key in Zernio and store it only as a server env var or connector secret, never in a prompt or file. Then pick the exact profile and connected accounts (platform plus ID) with the Social Media Manager; it verifies them read-only before any draft is created.
2. Meta Ads MCP: connect or reconnect it in the app's connector settings with the owner's own login. Select ONE ad account. The Performance Marketer confirms access with a read-only account and campaign list, and uses reporting tools only.
3. Record the chosen account names and IDs in the client folder (no secrets), and re-verify them before each use.
