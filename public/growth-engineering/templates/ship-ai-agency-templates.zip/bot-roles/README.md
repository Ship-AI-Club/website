# Ship AI marketing team: role sources (kit 1.2), 2026-10-14

Four marketing roles, plus Site Builder kept as a separate website setup specialist:
- social-media-manager/: calendar, organic copy, approvals, exact-destination Zernio drafts
- performance-marketer/: Meta Ad Library research, positioning, paid creative briefs, planning and analysis (no spend)
- content-creator-design/: static, photo-led creative
- content-creator-video/: research-informed storyboard, render and revision
- site-builder/: the client website (retained)

MASTER-PROMPT.md is the sequenced six-step workflow, and INTEGRATIONS.md is the integration map (planned, not verified). Public templates are staged but unpublished until the owner confirms each one. No secrets, history or routines are included. The workflow builder's --items selection ships in kit 1.2 from the owner's tested local change, which is not included here.
