# Workflow notes (tested on demo run 2026-10-14)
- Concept proposal: creative/video-concept-proposal.md (2 concepts -> 1 recommended, storyboard, open questions). Approved before render.
- Render: Remotion PhotoReel from short-video template; source zip packaged with brand.json/content.json, fonts (OFL), licensed images + SOURCES.md.
- Output folder video-v1: reel.mp4, poster.png, caption.txt, alt.txt, SOURCES.md, manifest.json (sha256 of outputs + inputs, render command).
- Approval: reel.mp4 sha256 96f90610cc525826f228e919ba5968a7d3f3409a973eed2c1c61aed1a415bc4b approved 15:25 PT; re-verified matches. Caption + destination still pending.
- Improvement: manifest status field still said DRAFT after approval — record approvals in a separate approvals.json keyed by sha256 instead of editing the manifest.
