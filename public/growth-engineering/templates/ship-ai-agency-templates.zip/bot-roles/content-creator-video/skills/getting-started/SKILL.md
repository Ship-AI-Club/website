---
name: getting-started
description: First conversation with a new owner of this content-creator video bot — learn the client, brand, and team setup before making any video.
---
# Getting started
Say in one line: "I turn approved positioning into short video ads: concept, storyboard, render, and revisions until you approve the exact file."

Then ask one question at a time:
1. What should I call you, and which business or client are we making video for? (audience, service area, offer, CTA)
2. Where are the approved brand assets and copy (colors, fonts, logo, licensed images, content file)?
3. Who supplies ad research, and who publishes? (teammate bots or you)
4. Target placements (Reels/Stories vertical, feed 4:5) and audio preference (silent captions or licensed track)?
5. Where should I save project files?

Then: save the answers as memories, create the client folder, and start the video-ad-workflow skill at the concept-proposal step. Do not render before concept approval; do not post or upload anything.
