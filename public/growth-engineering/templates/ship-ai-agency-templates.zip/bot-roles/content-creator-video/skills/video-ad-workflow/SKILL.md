---
name: video-ad-workflow
description: Use when making a short-form video ad or reel for a client — from research-backed concept proposal through approval, render, and a hash-pinned final-render feedback loop.
---
# Video ad workflow

## 1. Inputs
1. Load the approved client brief: positioning, CTA, brand tokens (colors, fonts, logo), licensed imagery, and content source file. Ask only for what is missing; never invent claims, prices, reviews, or contact details.
2. Take ad research from the research/performance teammate (or the user). Treat live ads as references, not proof of performance. If sources are inaccessible, say so.

## 2. Concept proposal (no rendering yet)
1. Propose two original concepts tied to the approved positioning; recommend one.
2. Give a concise storyboard: time, visual/asset, on-screen copy, motion, audio approach, CTA.
3. List specs (e.g. 1080x1920, H.264, 30fps, target length), safe-area plan, and open questions (new copy lines, footage vs stills, audio rights, extra crops).
4. Ask for feedback. Do not render until the user explicitly approves a concept. Silence or your own critique is not approval.

## 3. Render
1. Build an editable composition (e.g. Remotion) from a reusable template; keep client data in brand/content files, not in code.
2. Verify current placement specs and safe areas before export. Make it readable with sound off; use only rights-cleared audio or none.
3. Render the MP4, a poster frame, caption, and alt text into a versioned folder (video-v1, v2, ...).
4. Write a manifest: sha256 of every output and input, spec, template version, render command.

## 4. Final-render feedback loop (hash-pinned)
1. Show the actual video, poster, and caption. Report the file's sha256. Ask what to change.
2. Each revision is a new version folder with new hashes; never overwrite an approved file.
3. Approval applies only to the exact sha256 the user approved. Record version, hash, approver, and time.
4. Any change to the media resets approval. Before handoff, re-hash the file and confirm it matches the approved hash.
5. Caption and destination are separate approvals; track them as pending until explicitly approved.

## 5. Handoff
Package the approved bundle (media, hashes, caption, alt, links) locally for the publishing teammate. Never upload, post, or create drafts on a publishing platform without explicit approval of the exact bundle and destination.
