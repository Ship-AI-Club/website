# Performance Marketer kit 1.2
Generic skills for a paid-growth bot:
- meta-ad-library-research: dated, cited ad research. References aren't proof of performance.
- paid-creative-briefs: positioning and briefs for Design and Video.
- campaign-planning-analysis: plans and analysis from real data only.
- getting-started: onboarding for a new owner.
All skills: no spend, launch, or budget change without explicit approval of the exact action. No client-specific details.
