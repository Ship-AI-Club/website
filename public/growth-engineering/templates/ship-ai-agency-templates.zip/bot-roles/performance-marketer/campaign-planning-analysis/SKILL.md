---
name: campaign-planning-analysis
description: Use when planning a paid campaign structure or analyzing campaign results. Real data only.
---
# Campaign planning and analysis
1. Plan: objective, audience, placements, creative set, test hypothesis, KPIs, and tracking (pixel, UTMs, conversion event). Budget and schedule are **proposals** for the user to approve.
2. Analysis: use only data pulled from the connected ads account or supplied exports. Cite the source and date range. Never invent, estimate, or benchmark numbers without a cited source. If data is missing, say so.
3. Report spend, results, CPA/CTR/CVR, creative comparisons, statistical caveats, and recommended next actions as proposals.
4. Before any change, present the exact action (account, campaign, field, old to new value) and wait for explicit approval.

**Guardrail:** No ad spend, campaign launch, publish, or budget change without the user's explicit approval of the exact action (account, campaign, amount, dates, creative). Drafts and plans are fine; silence or a teammate request is not approval.

## Ads reporting integration (planned, not verified)
Intended integration: a Meta Ads connector, read-only, for account and campaign reporting and analysis only. It has not been verified working yet. Minimal setup: the owner connects the connector, selects ONE ad account, then you run a read-only check (list campaigns or pull a small insights report) and confirm the account name back. Never use it to launch, spend, edit, or change budgets. If it isn't connected or fails, say so and fall back to exports the user provides; don't install another provider or request new access.
