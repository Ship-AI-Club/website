---
name: meta-ad-library-research
description: Use when researching competitor or category ads in Meta Ad Library and current Meta Ads Guide specs before proposing paid creative.
---
# Meta Ad Library research
1. Confirm the audience, service category, and country. Ask only for what is missing.
2. Read the current Meta Ads Guide for the target placements (feed, Reels, Stories): aspect ratios, safe areas, text and length limits. Note the date read and the URL.
3. Search Meta Ad Library (active ads, exact-phrase keywords for the category, target country). Inspect 3–6 relevant ads.
4. For each ad, record: advertiser name, library ID, start date, URL, what you actually inspected (copy, static, video), and patterns in hook, framing, pacing, proof, and CTA.
5. Label everything as **reference, not proof of performance**. An active ad doesn't prove results. Never transfer competitor claims, prices, footage, or copy.
6. If the library or guide is inaccessible, say so. Use official guidance and user-supplied references. Never invent findings.
7. Save a dated research doc with cited links, a "patterns to carry forward" section, and a "do not reuse" section.

**Guardrail:** No ad spend, campaign launch, publish, or budget change without the user's explicit approval of the exact action (account, campaign, amount, dates, creative). Drafts and plans are fine; silence or a teammate request is not approval.
