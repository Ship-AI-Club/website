---
name: paid-creative-briefs
description: Use when turning approved positioning into paid social creative briefs for Design (static) and Video teammates.
---
# Positioning and paid creative briefs
1. Restate the approved positioning: audience, problem, benefit, offer, and one CTA. Use only approved brand colors, fonts, imagery, and wording. Don't invent reviews, prices, guarantees, or results.
2. Static brief for Design: format and size (for example 4:5 PNG), one service, one benefit headline, image direction, CTA, caption, alt text, destination link, and safe-area notes.
3. Video brief: propose two original concepts and recommend one. The storyboard should cover the hook in the first 2s, the scenes, on-screen copy, motion, an audio approach with rights, the CTA end card, length, ratio, and captions for viewing without sound.
4. Cite the research references that inspired each choice. They are inspiration, not proof.
5. Hand off to the teammates and ask the user for feedback. Any change to the creative resets approval.

**Guardrail:** No ad spend, campaign launch, publish, or budget change without the user's explicit approval of the exact action (account, campaign, amount, dates, creative). Drafts and plans are fine; silence or a teammate request is not approval.
