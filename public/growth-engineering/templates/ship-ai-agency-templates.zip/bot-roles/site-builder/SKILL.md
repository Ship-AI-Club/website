---
name: Ship AI Demo · Client site builder
description: >-
  Step 1 of the Ship AI agency workflow: build, QA and package a photo-led
  Next.js marketing site for a client from canonical brand.json + content.json.
  Use when asked to build, revise, export or package a client's site.
---
# Client site builder (agency step 1)
We are the agency; the site is the client's deliverable. Campaign Manager owns acceptance; Creative Studio supplies local, licensed imagery. Agency branding ('Practical AI, Built Together.') never enters client copy.

## Setup
1. Download https://www.shipai.club/growth-engineering/templates/ship-ai-agency-templates.zip, unzip into a FRESH run folder, read the root README and templates/client-website README.
2. Canonical inputs live at kit root `clients/<client>/brand.json` + `content.json`; the site reads them via `CLIENTS_DIR`. Never sync duplicate client copies into the template. New client: copy `clients/_template/`, fill from supplied facts only. Unknown facts stay null and out of copy. Never invent prices, reviews, ratings, guarantees, staff, insurance, phone or address.

## Build (no copy in components)
Nav; photo-led hero (large local image, deliberate headline line breaks, reads as the client's service); services each with own image, heading, 2-3 details and a `/quote?service=<id>` link that preselects (read query client-side); how it works; service area (honest: "share your ZIP and we'll confirm"); FAQ; final CTA; footer >=14px with a concise demo note + photo credits. Self-host fonts (@fontsource) and images; hero eager, others lazy. /quote: noValidate, inline errors (aria-invalid, aria-describedby, role=alert summary, focus first invalid), honest local summary "request prepared, nothing sent". No gradients, emoji, filler badges, fake stats.

## Quality gates (all must pass before reporting done)
- Normal mode (`next start`) and static export use SEPARATE build dirs; never build one while the other serves.
- Screenshots at 1440 and 390 for home + quote (empty-error, preselect, summary states); inspect them; no horizontal overflow; AA contrast; focus states; reduced motion; alt text.
- Static export served under its base path (e.g. /growth-engineering/<client>): index.html and quote/index.html, all assets under basePath, plain <a> nav, every route and asset 200, full quote flow works.
- Smoke test a second fictional client and the blank `_template`; rg template src for the client name, city and hero filenames: hits only in clients/.
- Pin the kit's patched Next version; lockfile committed; asset sync validates source before replacing.
- Package: unzip into a clean folder, run documented npm ci + build + export, confirm 200s. Ship SHA256 manifest; split into independent <19MB parts if needed.

Report what ran with exit codes and HTTP statuses. Never deploy or publish without explicit approval.
