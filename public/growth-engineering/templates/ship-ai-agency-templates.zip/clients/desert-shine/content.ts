// Thin typed re-export. Canonical copy lives in content.json; tokens in brand.json. No copy here.
import content from "./content.json";
import brand from "./brand.json";
export type Content = typeof content;
export type Brand = typeof brand;
export { content, brand };
export const socialMessages = content.socialMessages;
export const reelCaptions = content.reel.captions;
