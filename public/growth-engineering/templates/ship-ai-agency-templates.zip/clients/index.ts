// Client registry. Every consumer selects a client by id (default "desert-shine").
// Only imports here: no copy. Add a client = add a folder with brand.json + content.json and register it.
import dsBrand from "./desert-shine/brand.json";
import dsContent from "./desert-shine/content.json";
export const DEFAULT_CLIENT = "desert-shine";
const registry = { "desert-shine": { brand: dsBrand, content: dsContent } } as const;
export type ClientId = keyof typeof registry;
export type ClientData = (typeof registry)[ClientId];
export function getClient(id: string = DEFAULT_CLIENT): ClientData {
  const c = (registry as Record<string, ClientData>)[id];
  if (!c) throw new Error(`Unknown client "${id}". Known: ${Object.keys(registry).join(", ")}`);
  return c;
}
