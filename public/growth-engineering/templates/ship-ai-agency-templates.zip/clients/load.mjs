// Node loader for scripts (render-stills, review bundle). Reads the same canonical JSON files.
import fs from "node:fs"; import path from "node:path"; import { fileURLToPath } from "node:url";
const dir = path.dirname(fileURLToPath(import.meta.url));
export const DEFAULT_CLIENT = "desert-shine";
export function clientArg(argv = process.argv) { const i = argv.indexOf("--client"); return i > -1 ? argv[i + 1] : (process.env.CLIENT ?? DEFAULT_CLIENT); }
export function loadClient(id = DEFAULT_CLIENT) {
  const d = path.join(dir, id);
  if (!/^[a-z0-9-]+$/.test(id) || !fs.existsSync(d)) throw new Error(`Unknown client "${id}"`);
  const read = f => JSON.parse(fs.readFileSync(path.join(d, f), "utf8"));
  return { id, brand: read("brand.json"), content: read("content.json"), paths: { brand: path.join(d, "brand.json"), content: path.join(d, "content.json") } };
}
