// Renders 1080x1350 (and 1080x1080 with --square) stills via renderStill.
// No copy here: message ids come from ../clients/<client>/content.json; the composition reads the text itself.
// Usage: node render-stills.mjs [--square] [--client desert-shine]
import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";
import path from "node:path";
import { loadClient, clientArg } from "../clients/load.mjs";
const client = clientArg();
const { content } = loadClient(client);
const square = process.argv.includes("--square");
const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts") });
for (const id of square ? ["Social4x5", "Social1x1"] : ["Social4x5"]) for (const { id: msgId } of content.socialMessages) {
  const inputProps = { client, msgId };
  const composition = await selectComposition({ serveUrl, id, inputProps });
  const output = path.resolve(`../out/${msgId}-${id}.png`);
  await renderStill({ composition, serveUrl, output, inputProps });
  console.log("wrote", output);
}
