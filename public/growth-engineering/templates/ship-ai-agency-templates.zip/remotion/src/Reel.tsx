import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { getClient, DEFAULT_CLIENT } from "../../clients";
// No copy here: captions from clients/<client>/content.json (reel.captions), tokens from brand.json.
export const Reel: React.FC<{ client?: string }> = ({ client = DEFAULT_CLIENT }) => {
  const { brand, content } = getClient(client); const c = brand.tokens.colors; const reelCaptions = content.reel.captions;
  const f = useCurrentFrame(); const { fps } = useVideoConfig(); const t = f / fps;
  const cap = reelCaptions.find(x => t >= x.from && t < x.to) ?? reelCaptions[reelCaptions.length - 1];
  const isCta = cap === reelCaptions[reelCaptions.length - 1];
  const segStart = Math.round(cap.from * fps);
  const s = spring({ frame: f - segStart, fps });
  return (<AbsoluteFill style={{ background: isCta ? c.primary : c.background, fontFamily: brand.tokens.font, alignItems: "center", justifyContent: "center", padding: 80 }}>
    <div style={{ position: "absolute", top: 140, fontSize: 64, fontWeight: 900, color: isCta ? "#fff" : c.secondary }}>{brand.business.name}</div>
    <div style={{ fontSize: 96, fontWeight: 900, textAlign: "center", lineHeight: 1.1, maxWidth: 920, color: isCta ? "#fff" : c.text, transform: `scale(${0.9 + 0.1 * s})` }}>{cap.text}</div>
  </AbsoluteFill>);
};
