import { Composition, Still } from "remotion";
import { SocialStill } from "./SocialStill";
import { Reel } from "./Reel";
import { DEFAULT_CLIENT } from "../../clients";
// Pass { client, msgId } as inputProps to select a client; defaults to desert-shine / post-1.
export const Root = () => (<>
  <Still id="Social4x5" component={SocialStill} width={1080} height={1350} defaultProps={{ client: DEFAULT_CLIENT, msgId: "post-1" }} />
  <Still id="Social1x1" component={SocialStill} width={1080} height={1080} defaultProps={{ client: DEFAULT_CLIENT, msgId: "post-1" }} />
  <Composition id="Reel" component={Reel} durationInFrames={450} fps={30} width={1080} height={1920} defaultProps={{ client: DEFAULT_CLIENT }} />
</>);
