import { AbsoluteFill } from "remotion";
import { getClient, DEFAULT_CLIENT } from "../../clients";
// No copy here: headline/body/CTA come from clients/<client>/content.json, tokens from brand.json.
export type StillProps = { client?: string; msgId: string };
export const SocialStill: React.FC<StillProps> = ({ client = DEFAULT_CLIENT, msgId }) => {
  const { brand, content } = getClient(client);
  const c = brand.tokens.colors;
  const msg = content.socialMessages.find(m => m.id === msgId);
  if (!msg) throw new Error(`No social message "${msgId}" for client ${client}`);
  return (
  <AbsoluteFill style={{ background: c.background, fontFamily: brand.tokens.font, padding: 90, justifyContent: "space-between" }}>
    <div style={{ fontSize: 44, fontWeight: 800, color: c.secondary }}>{brand.business.name}</div>
    <div><div style={{ fontSize: 110, fontWeight: 900, color: c.text, lineHeight: 1.05 }}>{msg.headline}</div>
      <div style={{ fontSize: 48, color: c.text, marginTop: 30 }}>{msg.body}</div></div>
    <div style={{ background: c.primary, color: "#fff", fontSize: 46, fontWeight: 800, padding: "28px 40px", borderRadius: brand.tokens.radius, alignSelf: "flex-start" }}>{content.cta.label}</div>
  </AbsoluteFill>);
};
