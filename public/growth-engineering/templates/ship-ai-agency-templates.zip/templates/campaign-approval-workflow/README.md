# Campaign approval workflow (template) — DRY RUN

Builds one exact, versioned review bundle for a client campaign, gives it an approval hash, proves
edits void approval, and writes Zernio **draft** requests as local `NOT_SENT-*.json` files.
It makes no network calls, never contacts Zernio, never publishes, schedules or uploads.
`template/routine-template.md` is **DISABLED** and must stay that way.

## Inputs
- `<project>/clients/<client>/brand.json`: `business.name`, `business.type`, `business.audience`
- `<project>/clients/<client>/content.json`: `tagline`, `cta {label, href}`, `services[] {name, summary}`,
  `serviceArea.primary`, `socialMessages[] {id, headline, body}`, `reel {postText, captions[] {text}}`
- Media in `<project>/out/` (or `--media <dir>`): `site-snapshot.png`, `site-quote.png`,
  `<id>-Social4x5.png` + `<id>-Social1x1.png` for each social message, and `reel.mp4` (1080x1920, 15 s)

## Outputs (in `--out`, default `<project>/review`)
- `bundle.json`: bundleId, version, exact captions, media paths with sha256, placeholder destinations,
  `scheduledTime: null`, `approval: null`, `approvalHashExpected`
- `review-bundle.md` / `review-bundle.html`: what the human reviews. Media links are relative to the bundle folder.
- `media/` (only with `--copy-media`): the bundle is self-contained and portable.
- `<outbox>/NOT_SENT-<bundleId>-<item>.json`: one Zernio draft request per item (draft mode, placeholders only)

## Run (one command, from this folder)
```bash
node template/build-review-bundle.mjs --project ../.. --client desert-shine --out runs/desert-shine --outbox runs/desert-shine/outbox --media example/desert-shine/media --copy-media --version v1 && bash template/approval-test.sh runs/desert-shine/bundle.json | tee runs/desert-shine/approval-test.log
```
`approval-test.sh` runs only on a temporary copy. It checks: unapproved → INVALID, simulated approve → VALID,
caption edit → INVALID, restore → VALID, destination edit → INVALID, restore → VALID.
Check a real approval at any time with `node template/approval-hash.mjs <bundle.json> --check`.

## Using it for another client
1. Create `<project>/clients/<new-client>/brand.json` and `content.json` with the fields above. The id must be lowercase letters, digits and hyphens.
2. Render the site screenshots, stills and reel into `<project>/out/` (or pass `--media`).
3. Run the command above with `--client <new-client>` and new `--out`/`--outbox` folders. Destinations become
   `<NEW_CLIENT_ZERNIO_ACCOUNT_ID>` placeholders. Use that client's own Zernio profile/accounts only, never agency ones.
4. Send `review-bundle.html` to the human and wait for `APPROVE <hash>`. Bump `--version` after any change.
5. Sending is out of scope here: follow SKILL.md step 6 only after a valid approval and an explicit decision to send.

## Example
`example/desert-shine/` was built with `--copy-media --version v2`. It is unapproved (`approval: null`).

## Exact delivery selection
Each item lists all review media and an explicit non-empty `deliveryMedia` subset. A static draft defaults to its 4×5 portrait only; the square is a review alternative. Changing the selected variant changes the approval fingerprint. Empty or unrelated selections are rejected.

`idempotency.json` persists a UUID for each bundle-version/item. The local request preview uses this as `Idempotency-Key`. Rebuilding the same logical draft preserves the key. Start a new version after content or destination changes. Keep local file hashes outside the API body.

Use `--shots site-home-desktop.png,site-home-mobile.png,site-quote-desktop.png,site-quote-mobile.png` for four screenshots; defaults remain `site-snapshot.png,site-quote.png`. Optional `--source-json <file>` records sourceVersion and destinationStatus metadata. The builder does not perform network requests.

## Review one creative before expanding

The master workflow starts with one static draft and a feedback loop. The builder supports this without requiring unapproved variants or a video:

```bash
node templates/campaign-approval-workflow/template/build-review-bundle.mjs --project . --client desert-shine --media out --items post-1 --out runs/desert-shine/static-v1 --outbox runs/desert-shine/static-v1/outbox --copy-media --version static-v1
```

Only the selected item and the website screenshots are required. A square variant is included as a review alternative when present; the portrait remains the selected delivery asset. To review the approved static and completed video together, use `--items post-1,reel` with a new bundle version and new output directory. Without `--items`, the builder includes every configured social message and the reel for the complete reference campaign. Unknown, duplicate and empty selections fail. Missing selected media also fails.

Keep each review version in its own directory, preserve previous versions, and use the exact outbox file list returned by the builder. Do not gather requests from an older run by globbing a shared outbox. New items or edits require a new exact-version approval.

Run `node --test templates/campaign-approval-workflow/template/build-review-bundle.test.mjs` for the feedback-first selection cases. The full reference bundle also supports the existing 15-check approval test. The scripts still make no network requests.
