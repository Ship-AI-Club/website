---
name: campaign-approval-workflow
description: Coordinate a client campaign and prepare an exact-version review bundle in dry run.
---
Read root README and this template's README. We are the agency. Use only the selected client's sources, media, and destinations.

1. Ask Site Builder for approved brand/content JSON and site screenshots. Ask Creative Studio for the stills and video. Keep all files inside the kit's client campaign workspace.
2. Run `template/build-review-bundle.mjs` with explicit --project, --client, --media, --out, --outbox, and --version values. The script saves a portable HTML review, JSON bundle, and NOT_SENT draft request previews. It does not send.
3. Show the exact captions, media, client, account destinations, and version. Destinations start as placeholders. Replace them only with verified client accounts, rebuild requests, then ask for review.
4. Run `template/approval-test.sh <bundle.json>`. Record a real approval only when the owner approves the exact hash shown by `template/approval-hash.mjs`. Check with --check immediately before a handoff. Changes to content, media, deliveryMedia selection, destination, or time invalidate approval. Use one selected graphic per static draft; keep square variants as alternatives. Missing media cannot be approved.
5. Keep dry run as default. No credentials are packaged. A separately implemented sender must read its API key server-side, verify account ownership and exact-version approval, upload approved media, then POST to https://zernio.com/api/v1/posts. Per https://docs.zernio.com/, omit scheduledFor, publishNow, and queue settings to save a draft; use the stored Idempotency-Key per logical draft for retries and verify the returned draft status. Recheck current API docs before implementing a sender.
6. Scheduling and publishing need a separate owner decision. Leave routine-template.md disabled. Report NOT SENT until an actual draft creation response is verified.

Rehearsal: “Use Campaign Approval Workflow for Desert Shine in dry run. Show the bundle and demonstrate that changing a caption resets approval.”
