# Review bundle: desert-shine-redesign-2026-10-14 (v3) — MODE: DRY RUN
Business: Client: Desert Shine — prepared by our agency
Website snapshot: media/site-snapshot.png · Quote form: media/site-quote.png

## Website brief
- Desert Shine: Residential housecleaning company for Phoenix homeowners
- Tagline: More sunshine. Less housework.
- CTA: Request a cleaning quote → /quote
- Regular Cleaning: Recurring upkeep so the house stays easy to live in: kitchen counters and appliances wiped down, bathrooms cleaned, floors vacuumed and mopped, surfaces dusted.
- Deep Cleaning: A top-to-bottom reset for built-up dust and grime: baseboards, door frames, fixtures and the corners regular upkeep skips. A good first visit or seasonal refresh.
- Move-Out Cleaning: Empty-home cleaning to get a property ready for handoff, whether you're moving out, moving in or preparing a home for the next owner.
- Service area: Phoenix, AZ
- Not claimed: prices, testimonials, licenses, insurance, discounts, contact details — intentionally not claimed

![site](media/site-snapshot.png) ![quote](media/site-quote.png)

| # | Item | Final text | Media (sha256) |
|---|------|-----------|-------|
| 1 | social-v1 | More sunshine. Less housework. Desert Shine's regular cleaning keeps your Phoenix home easy to live in: kitchen counters and appliances wiped down, bathrooms cleaned, floors vacuumed and mopped, surfaces dusted. Request a cleaning quote. | **DELIVER** media/social-v1.png (`c741c20f0e46…`) |
| 2 | video-v1 | Make room for your weekend. Desert Shine offers regular, deep and move-out house cleaning for Phoenix homeowners, so your weekends go to sunshine instead of scrubbing. More sunshine. Less housework. Request a cleaning quote. | **DELIVER** media/video-v1.mp4 (`96f90610cc52…`) |

Reel: 1080x1920, 15 s; burned-in captions: More sunshine. / Less housework. / Regular · Deep · Move-out / A little more room for life. / More sunshine. / Less housework.

## Media sha256
- media/social-v1.png: `c741c20f0e46de3b38916602a0df2af4d4435ca0d668962622247593f14e9630`
- media/video-v1.mp4: `96f90610cc525826f228e919ba5968a7d3f3409a973eed2c1c61aed1a415bc4b`
- media/site-snapshot.png: `4ad9f405a8295afff6c0d2c9d59f2afd536507160944798804e8f6e6b5dbfb6a`
- media/site-quote.png: `415c82b80052cdfa46188db8183ad6e2d36b6e31d2669c1ae304c22af0c6445b`

Destinations: <PLATFORM> / account <DESERT_SHINE_ZERNIO_ACCOUNT_ID> / profile <DESERT_SHINE_ZERNIO_PROFILE_ID> (client desert-shine)   (placeholders until an account/profile is chosen)
Destinations must be Desert Shine profile/accounts only.
Scheduled time: none — scheduling is a separate later decision
Approval hash (sha256 of bundleId + version + text + media bytes + destinations + time): `3739bc94ba66fb2a283a71b709f86bdf2452cdb1aa057421f617834e42badd0a`
Approval status: NOT APPROVED

To approve EXACTLY this version, reply: `APPROVE 3739bc94ba66fb2a283a71b709f86bdf2452cdb1aa057421f617834e42badd0a`
Any edit to any item, media, destination or time produces a new hash and voids this approval.
Approval authorizes ONLY Zernio draft creation (omit scheduledFor and publishNow). It does not schedule or publish.
