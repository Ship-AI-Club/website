# Desert Shine rehearsal 2026-10-14 — evidence report (DRY RUN)
RUN=/workspace/ship-ai-demo/rehearsals/desert-shine-2026-10-14. Nothing deployed, uploaded, sent, scheduled or published. No Zernio/network calls.

## Source version
- kit.zip sha256 `265113af4eefbd8bc88479ddc75f5619c5a5248c5a8d1ce9421a3a0d44b5bf7e` (template-manifest.json has no version field)
- clients/desert-shine/brand.json `285fc3e72d74b25ba32814c870187a663d5fc944e40d639ef705e095bae511d5`
- clients/desert-shine/content.json `73bfc811a3f4e51fd76aba92320f3ae0375d35ffc0f89542a2a39202228bfa98`

## Site Builder (reported by that bot; all exit 0)
| Command | Exit |
|---|---|
| cp root clients/desert-shine/{brand,content}.json → templates/client-website/template/clients/desert-shine/ + sha256 diff (identical) | 0 |
| port 3200 free check | 0 |
| cd templates/client-website/template && npm ci | 0 |
| NEXT_PUBLIC_CLIENT=desert-shine npm run build (/, /quote static) | 0 |
| NEXT_PUBLIC_CLIENT=desert-shine npx next start -p 3200 (left running, log /tmp/r-start.log) | running |
| HTTP GET / → 200, /quote → 200 | — |
| Playwright capture 1440 desktop / 390@2x mobile → out/site-{home,quote}-{desktop,mobile}.png | 0 |
Note: Site Builder synced the root JSON into the template copy rather than using CLIENTS_DIR as the kit README shows; files were byte-identical, so output is equivalent.

## Creative Studio (reported by that bot; all exit 0)
| Command | Exit |
|---|---|
| cd RUN/remotion && npm ci (0 vulnerabilities) | 0 |
| node ../templates/social-graphics/template/render-stills.mjs --client desert-shine | 0 |
| node ../templates/short-video/template/render-reel.mjs --client desert-shine | 0 |
| ffprobe width,height,duration on 7 files | 0 |
| ffmpeg -i reel.mp4 -vf fps=1 (15 frames) | 0 |
| grep -rniE "Practical AI\|Built Together\|Ship AI" clients templates remotion/src | 0 (only internal brand.json note) |

## Campaign Manager (this run)
| Command | Exit | Result |
|---|---|---|
| ffprobe -v error -show_entries stream=codec_name,width,height:format=duration on all 11 files in out/ | 0 each | 4x5 PNGs 1080x1350; 1x1 PNGs 1080x1080; reel h264 1080x1920 15.000000 s; site home-desktop 1440x904, quote-desktop 1440x900, home-mobile 780x2630, quote-mobile 780x1736 |
| ffmpeg -i out/reel.mp4 -vf fps=1/5 (3 frames) + hstack contact sheets of stills/screenshots, viewed | 0 | All readable, nothing clipped; copy intact |
| sha256sum kit.zip clients/desert-shine/*.json | 0 | see above |
| node templates/campaign-approval-workflow/template/build-review-bundle.mjs --project . --client desert-shine --media <staging copy of out/> --out review --outbox outbox --copy-media --version v1 --bundle-id desert-shine-rehearsal-2026-10-14 --shots site-home-desktop.png,site-home-mobile.png,site-quote-desktop.png,site-quote-mobile.png --source-json <source/status json> | 0 | hash 999da6f26bb7ed1214030bc6fca8fbded1f5db25db40becc6a44480da3171c26 |
| node .../approval-hash.mjs review/bundle.json --check | 1 | APPROVAL INVALID (final bundle unapproved, as intended) |
| cp -r review /tmp/dstest && bash .../approval-test.sh /tmp/dstest/bundle.json > review/approval-test.log | 0 | 10/10 PASS |
| rg 'Build. Learn. Ship.' RUN (excl node_modules/.next) ; unzip -p kit.zip \| grep -c | 1 / 0 | no occurrences |
| rg -i 'practical ai\|built together' RUN | 1 | no occurrences |
| rg -c '"isDraft": true' outbox | 0 | 4/4 files |

Final review/bundle.json sha256: `b7ab207bead6e88bd4e8d6db5f803f52dedf0cdea1f3c0a44e656b9a919296df`; approval: null; scheduledTime: null.

## Fixes to the kit's campaign-approval-workflow template (in RUN only)
1. build-review-bundle.mjs: `--shots` option (kit hard-coded site-snapshot.png/site-quote.png; Site Builder produced 4 screenshots); `--source-json` to record source version + destination status in bundle/md/html; `isDraft: true` in NOT_SENT request bodies.
2. approval-test.sh: added explicit restore→VALID checks after caption and destination edits; added a REAL deleted-file test (media moved aside with approval hash unchanged → INVALID, restored → VALID); fixed reading of the temp bundle with JSON.parse. Kit's existing missing-media test (path edit) already returned INVALID — no logic fix needed in approval-hash.mjs.

## Destinations
BLOCKED: no Zernio API credential in env or any secure store. No profile/account read-only check was done. Placeholders <PLATFORM>, <DESERT_SHINE_ZERNIO_ACCOUNT_ID>, <DESERT_SHINE_ZERNIO_PROFILE_ID>.

---
# v2 — handoff defect fix (2026-10-14, DRY RUN; no rerender, no network)
Defect fixed: v1 outbox delivered BOTH 4x5 and 1x1 images per static post and leaked local-only `_localSha256` into the API body; idempotency key was a placeholder.

## v1 preservation
| Command | Exit | Result |
|---|---|---|
| sha256 of every file in review/ + outbox/ → /tmp/v1.before | 0 | 17 files |
| mv review/{bundle.json,review-bundle.md,review-bundle.html,approval-test.log,media} → review/archive/v1/review/; mv outbox/NOT_SENT-*.json → review/archive/v1/outbox/ | 0 | |
| re-hash archive and diff vs before (run twice: after move and before zipping) | 0 | V1_FILES_UNCHANGED |
| node approval-hash.mjs review/archive/v1/review/bundle.json (new script, backward compatible) | 0 | 999da6f26bb7ed1214030bc6fca8fbded1f5db25db40becc6a44480da3171c26 (= v1 hash) |

## Script changes (templates/campaign-approval-workflow/template/)
- build-review-bundle.mjs: per-item `deliveryMedia` (static posts → only `*-Social4x5.png`; 1x1 kept in `media` + `reviewAlternatives`; reel → reel.mp4); throws if deliveryMedia empty or not ⊆ media; `requireDeliveryMedia:true`; persisted `idempotency.json` keyed `<bundleId>@<version>#<item>` (reused on rebuild) mirrored into `bundle.idempotencyKeys`; outbox body.mediaItems = {type,url} only; hashes moved to top-level `_localMedia`; `Idempotency-Key` header; `isDraft:true`; md/html mark DELIVER vs review alternative.
- approval-hash.mjs: hash now binds deliveryMedia path+sha256; exit 2 (APPROVAL INVALID, malformed) when deliveryMedia empty/non-subset; missing delivery file → INVALID. Bundles without deliveryMedia (v1) hash identically to before.
- approval-test.sh: +5 checks (square delivery INVALID, restore VALID, empty → exit 2, non-subset → exit 2, final restore VALID); missing-media path test updated to keep deliveryMedia consistent.
- templates/client-website/template/clients/load.mjs: now honors CLIENTS_DIR (lib/client.ts already did).
- README.md (root) + templates/client-website/README.md: full-kit runs use CLIENTS_DIR=../../../clients directly; no syncing duplicate JSON.

## v2 commands
| Command | Exit | Result |
|---|---|---|
| node build-review-bundle.mjs --project . --client desert-shine --media /tmp/dsstage (copy of out/, not rerendered) --out review/v2 --outbox outbox/v2 --copy-media --version v2 --bundle-id desert-shine-rehearsal-2026-10-14 --shots site-home-desktop.png,site-home-mobile.png,site-quote-desktop.png,site-quote-mobile.png --source-json <src> | 0 | hash 2f562b585e29e5ea1f4cb1f098d28db9f16dbd2c4a287e40242e913c4c878c63 |
| same command again (rebuild) + diff idempotency.json + compare hash | 0 | PASS: rebuild keeps same idempotency keys and hash (review/v2-build.log) |
| cp -r review/v2 /tmp/dstest2 && bash approval-test.sh /tmp/dstest2/bundle.json > review/v2/approval-test.log | 0 | 15/15 PASS |
| node approval-hash.mjs review/v2/bundle.json --check | 1 | APPROVAL INVALID (unapproved, intended) |
| CLIENTS_DIR=/tmp/sent node (load.mjs loadClient zz-sentinel) | 0 | SENTINEL |
| typescript transpile lib/client.ts; CLIENTS_DIR=/tmp/sent NEXT_PUBLIC_CLIENT=zz-sentinel node import | 0 | "SENTINEL \| from CLIENTS_DIR" (next build skipped: would overwrite .next served by Site Builder on :3200) |

Final v2 bundle.json sha256 `200a4d952c92caa0adc761771a8ca7fe3c18f98f876b91a9595255b2dd207af2`; approval null; scheduledTime null; destinations BLOCKED placeholders (no Zernio credential).
