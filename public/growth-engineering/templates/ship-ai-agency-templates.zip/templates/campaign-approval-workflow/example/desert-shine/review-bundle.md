# Review bundle: desert-shine-rehearsal-2026-10-14 (v2) — MODE: DRY RUN
Business: Client: Desert Shine — prepared by our agency
Website snapshot: media/site-home-desktop.png · Quote form: media/site-home-mobile.png

## Website brief
- Desert Shine: Residential housecleaning company for Phoenix homeowners
- Tagline: A cleaner Phoenix home, without the hassle.
- CTA: Request a cleaning quote → /quote
- Regular Cleaning: Recurring upkeep of kitchens, baths, floors and living areas.
- Deep Cleaning: Top-to-bottom detail work for built-up dust and grime.
- Move-Out Cleaning: Empty-home cleaning to get a property ready for handoff.
- Service area: Phoenix, AZ
- Not claimed: prices, testimonials, licenses, insurance, discounts, contact details — intentionally not claimed

![site](media/site-home-desktop.png) ![quote](media/site-home-mobile.png)

| # | Item | Final text | Media (sha256) |
|---|------|-----------|-------|
| 1 | post-1 | Come home to clean. Regular cleaning for Phoenix homeowners. Request a cleaning quote. | **DELIVER** media/post-1-Social4x5.png (`a919b130b0ff…`)<br>review-alt media/post-1-Social1x1.png (`264bf6f506ab…`) |
| 2 | post-2 | Deep clean, done right. Detail work for built-up dust and grime. Request a cleaning quote. | **DELIVER** media/post-2-Social4x5.png (`4a4c8f8f4249…`)<br>review-alt media/post-2-Social1x1.png (`7288e92b043e…`) |
| 3 | post-3 | Moving out? Move-out cleaning to hand off a spotless home. Request a cleaning quote. | **DELIVER** media/post-3-Social4x5.png (`9a3ec25aeea0…`)<br>review-alt media/post-3-Social1x1.png (`c50893e171e7…`) |
| 4 | reel | Regular, deep and move-out cleaning for Phoenix homeowners. Request a cleaning quote. | **DELIVER** media/reel.mp4 (`229311923246…`) |

Reel: 1080x1920, 15 s; burned-in captions: Phoenix homeowners: / Regular • Deep • Move-out cleaning / Desert Shine handles the mess. / Request a cleaning quote

## Media sha256
- media/post-1-Social4x5.png: `a919b130b0ff2ffd65a183a294650695efb68beb34e59bf06dd3af50e8b02192`
- media/post-1-Social1x1.png: `264bf6f506ab8a7f716abc7d86bb9d12ba52a2874a1123df2f3cc07fe59191a2`
- media/post-2-Social4x5.png: `4a4c8f8f42492831768d86b97ee5d19af4c4883430e82521b0fc0676bd4a66d4`
- media/post-2-Social1x1.png: `7288e92b043ed8244122429d66dfbedce1bc1aa6bc3f3a569ca706f4dac69ad0`
- media/post-3-Social4x5.png: `9a3ec25aeea051dbb794e0e4faff343b566a18de99f9791c3634ec4a2971284d`
- media/post-3-Social1x1.png: `c50893e171e7c98d2580942dc29e62ee0b44655a5588bd276015dc0b267cc39c`
- media/reel.mp4: `2293119232464126d1c9d993b3916bfe64500abf49859f69204a9257e6390c2e`
- media/site-home-desktop.png: `2846a11a26cb144d7c7a23e5f86f0c16302c1d82d0cf2bde9fa52257789a7910`
- media/site-home-mobile.png: `6ab3b839e718094d0d064247c56afd8593451e70c876843005b7c8ec535823cc`
- media/site-quote-desktop.png: `e6e1965272eee0cb52d48cd0cb81cb183f86b10a6f4e297332a6a2941496a33f`
- media/site-quote-mobile.png: `efb99057deb26cf27200673521e208bd0a0f7247ee04a7739ca6d7623f65ca07`

Destinations: <PLATFORM> / account <DESERT_SHINE_ZERNIO_ACCOUNT_ID> / profile <DESERT_SHINE_ZERNIO_PROFILE_ID> (client desert-shine)   (placeholders until an account/profile is chosen)
Destinations must be Desert Shine profile/accounts only.
## Source version / status
```json
{
  "sourceVersion": {
    "kit": "ship-ai-agency-templates (no version field in manifest)",
    "kitZipSha256": "265113af4eefbd8bc88479ddc75f5619c5a5248c5a8d1ce9421a3a0d44b5bf7e",
    "brandJsonSha256": "285fc3e72d74b25ba32814c870187a663d5fc944e40d639ef705e095bae511d5",
    "contentJsonSha256": "73bfc811a3f4e51fd76aba92320f3ae0375d35ffc0f89542a2a39202228bfa98",
    "rehearsal": "desert-shine-2026-10-14"
  },
  "destinationStatus": "BLOCKED: no Zernio API credential in env or any secure store; no Zernio profile/account lookup performed. Destinations are placeholders and cannot be sent."
}
```

Scheduled time: none — scheduling is a separate later decision
Approval hash (sha256 of bundleId + version + text + media bytes + destinations + time): `2f562b585e29e5ea1f4cb1f098d28db9f16dbd2c4a287e40242e913c4c878c63`
Approval status: NOT APPROVED

To approve EXACTLY this version, reply: `APPROVE 2f562b585e29e5ea1f4cb1f098d28db9f16dbd2c4a287e40242e913c4c878c63`
Any edit to any item, media, destination or time produces a new hash and voids this approval.
Approval authorizes ONLY Zernio draft creation (omit scheduledFor and publishNow). It does not schedule or publish.
