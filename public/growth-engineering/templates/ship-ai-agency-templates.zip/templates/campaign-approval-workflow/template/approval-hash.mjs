#!/usr/bin/env node
// Usage: node approval-hash.mjs <bundle.json> [--check]
// Hash = sha256 over canonical JSON of {bundleId, version, per item: id, text, review media (path+sha256),
// deliveryMedia (path+sha256), destinations, scheduledTime}. Any change => prior approval INVALID.
// Exit 2 if deliveryMedia is empty or not a subset of the item's review media (bundle malformed).
import fs from "node:fs"; import crypto from "node:crypto"; import path from "node:path";
const file = process.argv[2] ?? "review/bundle.json";
const b = JSON.parse(fs.readFileSync(file, "utf8")); const base = path.dirname(path.resolve(file));
const sha = d => crypto.createHash("sha256").update(d).digest("hex");
const canon = v => Array.isArray(v) ? v.map(canon) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map(k => [k, canon(v[k])])) : v;
const ent = m => { const p = path.resolve(base, m); return { path: m, sha256: fs.existsSync(p) ? sha(fs.readFileSync(p)) : "MISSING" }; };
const errs = [];
const items = b.items.map(it => { const media = it.media ?? [];
  if (it.deliveryMedia !== undefined || b.requireDeliveryMedia) {
    const d = it.deliveryMedia;
    if (!Array.isArray(d) || d.length === 0) errs.push(`${it.id}: deliveryMedia empty`);
    else for (const m of d) if (!media.includes(m)) errs.push(`${it.id}: deliveryMedia ${m} not in review media`); }
  const o = { id: it.id, text: it.text, media: media.map(ent) };
  if (it.deliveryMedia !== undefined) o.deliveryMedia = (it.deliveryMedia ?? []).map(ent);
  return o; });
if (errs.length) { console.error("ERROR: invalid deliveryMedia: " + errs.join("; ")); if (process.argv.includes("--check")) console.log("APPROVAL INVALID (malformed deliveryMedia)"); process.exit(2); }
const payload = canon({ bundleId: b.bundleId, version: b.version, items, destinations: b.destinations, scheduledTime: b.scheduledTime ?? null });
const hash = sha(JSON.stringify(payload));
const missing = items.some(i => [...i.media, ...(i.deliveryMedia ?? [])].some(m => m.sha256 === "MISSING"));
if (missing) console.error("WARNING: missing media; bundle not approvable");
console.log(hash);
if (process.argv.includes("--check")) { const ok = !missing && b.approval?.hash === hash; console.log(ok ? "APPROVAL VALID" : "APPROVAL INVALID (bundle changed or not approved)"); process.exit(ok ? 0 : 1); }
