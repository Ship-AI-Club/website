#!/usr/bin/env bash
# Tests a temporary copy beside the bundle; the original stays unapproved.
set -eu
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$(node -e 'console.log(require("path").resolve(process.argv[1]))' "${1:?bundle.json path}")"
B="$(mktemp "$(dirname "$SRC")/.approval-test.XXXXXX")"
trap 'rm -f "$B" "$B.approved"' EXIT
cp "$SRC" "$B"
hash(){ node "$HERE/approval-hash.mjs" "$B" "$@"; }
edit(){ node -e 'const fs=require("fs");const f=process.argv[1];const b=JSON.parse(fs.readFileSync(f));('"$1"')(b);fs.writeFileSync(f,JSON.stringify(b,null,2)+"\n")' "$B" "${2:-}"; }
check(){
  expected="$1"; label="$2"
  if hash --check; then actual=0; else actual=$?; fi
  if [ "$actual" -ne "$expected" ]; then echo "FAIL: $label (exit $actual)"; exit 1; fi
  echo "PASS: $label"
}
echo "Approval test $(date -u '+%Y-%m-%dT%H:%M:%SZ') — simulated approval only"
edit 'b=>{b.approval=null}'
H="$(hash)"
check 1 'unapproved bundle rejected'
edit 'b=>{b.approval={hash:process.argv[2],approvedBy:"SIMULATED_APPROVER",approvedAt:new Date().toISOString()}}' "$H"
cp "$B" "$B.approved"
check 0 'exact version accepted'
edit 'b=>{b.items[0].text+=" edited"}'
check 1 'caption edit invalidates approval'
cp "$B.approved" "$B"
check 0 'caption restored: exact version accepted'
edit 'b=>{b.destinations[0].zernioAccountId="OTHER_ACCOUNT"}'
check 1 'destination edit invalidates approval'
cp "$B.approved" "$B"
check 0 'destination restored: exact version accepted'
edit 'b=>{const o=b.items[0].media[0];b.items[0].media[0]="missing-file.png";if(b.items[0].deliveryMedia)b.items[0].deliveryMedia=b.items[0].deliveryMedia.map(m=>m===o?"missing-file.png":m)}'
H="$(hash)"
edit 'b=>{b.approval.hash=process.argv[2]}' "$H"
check 1 'missing media cannot be approved'
cp "$B.approved" "$B"
check 0 'media path restored: exact version accepted'
# Real missing file: move one referenced media file aside (restored by trap/explicitly)
MF="$(node -e 'const b=JSON.parse(require("fs").readFileSync(process.argv[1]));console.log(require("path").resolve(require("path").dirname(process.argv[1]),b.items[0].media[0]))' "$B")"
mv "$MF" "$MF.testhidden"; trap 'rm -f "$B" "$B.approved"; [ -e "$MF.testhidden" ] && mv "$MF.testhidden" "$MF"' EXIT
check 1 'deleted media file (approved hash unchanged) rejected'
mv "$MF.testhidden" "$MF"
check 0 'media file restored: exact version accepted'
cp "$B.approved" "$B"
edit 'b=>{const it=b.items.find(i=>i.deliveryMedia&&i.media.length>1);it.deliveryMedia=[it.media.find(m=>/1x1/.test(m))]}'
check 1 'deliveryMedia switched to square invalidates approval'
cp "$B.approved" "$B"
check 0 'deliveryMedia restored: exact version accepted'
edit 'b=>{b.items[0].deliveryMedia=[]}'
check 2 'empty deliveryMedia rejected as malformed'
cp "$B.approved" "$B"
edit 'b=>{b.items[0].deliveryMedia=[b.items[1].media[0]]}'
check 2 'non-subset deliveryMedia rejected as malformed'
cp "$B.approved" "$B"
check 0 'final restore: exact version accepted'
echo 'Original bundle untouched. No requests sent.'
