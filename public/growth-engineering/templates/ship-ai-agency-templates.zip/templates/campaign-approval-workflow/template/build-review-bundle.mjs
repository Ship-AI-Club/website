#!/usr/bin/env node
// DRY RUN review-bundle builder. No network calls. Writes bundle.json, review-bundle.md/.html and NOT_SENT outbox JSON.
// Usage: node build-review-bundle.mjs --project <dir> [--client desert-shine] [--out <dir>] [--outbox <dir>]
//        [--media <dir>] [--copy-media] [--version v1] [--bundle-id <id>] [--items post-1,reel]
// Reads <project>/clients/<client>/{brand.json,content.json}; media from <media> (default <project>/out).
import fs from "node:fs"; import path from "node:path"; import crypto from "node:crypto"; import {execFileSync} from "node:child_process"; import {fileURLToPath} from "node:url";
const HERE = path.dirname(fileURLToPath(import.meta.url));
const arg = (k, d) => { const i = process.argv.indexOf(k); return i > -1 ? process.argv[i+1] : d; };
const PROJECT = path.resolve(arg("--project", process.cwd()));
const client = arg("--client", process.env.CLIENT ?? "desert-shine");
if (!/^[a-z0-9-]+$/.test(client)) throw new Error("bad client id");
const OUT = path.resolve(arg("--out", path.join(PROJECT, "review")));
const OUTBOX = path.resolve(arg("--outbox", path.join(PROJECT, "outbox")));
const MEDIA = path.resolve(arg("--media", path.join(PROJECT, "out")));
const COPY = process.argv.includes("--copy-media");
const VERSION = arg("--version", "v1"); const BUNDLE_ID = arg("--bundle-id", `${client}-demo-001`);
const cdir = path.join(PROJECT, "clients", client);
const read = f => JSON.parse(fs.readFileSync(path.join(cdir, f), "utf8"));
const brandTokens = read("brand.json"), content = read("content.json");
const richSocial = content.socialCreatives ?? [];
const richVideo = content.video?.reels ?? [];
const modern = richSocial.length > 0 || richVideo.length > 0;
const availableItems = modern ? [...richSocial, ...richVideo].map(m=>m.id) : [...(content.socialMessages ?? []).map(m=>m.id), "reel"];
const itemArgument = arg("--items", null);
const selectedItems = itemArgument === null ? availableItems : itemArgument.split(",").map(s=>s.trim());
if (!selectedItems.length || selectedItems.some(id=>!id || !availableItems.includes(id)) || new Set(selectedItems).size !== selectedItems.length) throw new Error("--items must name unique available items: "+availableItems.join(","));
const sha = f => crypto.createHash("sha256").update(fs.readFileSync(f)).digest("hex");
const PH = client.toUpperCase().replace(/-/g, "_");
fs.mkdirSync(OUT, {recursive:true}); fs.mkdirSync(OUTBOX, {recursive:true});
// media path as stored in the bundle (relative to the bundle dir)
const mediaDirInBundle = COPY ? path.join(OUT, "media") : MEDIA;
if (COPY) fs.mkdirSync(mediaDirInBundle, {recursive:true});
const ref = name => { if (!/^[a-zA-Z0-9_-]+\.[a-zA-Z0-9]+$/.test(name)) throw new Error("media must be a filename inside --media"); const src = path.join(MEDIA, name); if (!fs.existsSync(src)) throw new Error("missing media "+src);
  if (COPY) fs.copyFileSync(src, path.join(mediaDirInBundle, name));
  return path.relative(OUT, path.join(mediaDirInBundle, name)).split(path.sep).join("/"); };
const name = brandTokens.business?.name ?? client; const cta = content.cta.label;
const items = modern ? [
 ...richSocial.filter(m=>selectedItems.includes(m.id)).map(m=>{ const p=ref(`${m.id}.png`); return {id:m.id,text:m.caption,alt:m.alt,media:[p],deliveryMedia:[p],sourceCreativeId:m.id}; }),
 ...richVideo.filter(m=>selectedItems.includes(m.id)).map(m=>{ const p=ref(`${m.id}.mp4`); return {id:m.id,text:m.caption,alt:m.alt,media:[p],deliveryMedia:[p],videoSpec:{width:1080,height:1920,durationSec:m.durationSec},burnedInCaptions:m.scenes.flatMap(s=>s.headlineLines ?? (s.headline ? [s.headline] : [])),sourceCreativeId:m.id}; })
] : [
 ...content.socialMessages.filter(m=>selectedItems.includes(m.id)).map(m => { const p=ref(`${m.id}-Social4x5.png`), square=`${m.id}-Social1x1.png`, alternatives=fs.existsSync(path.join(MEDIA,square))?[ref(square)]:[]; return { id:m.id, text:`${m.headline} ${m.body} ${cta}.`, media:[p,...alternatives], deliveryMedia:[p], reviewAlternatives:alternatives }; }),
 ...(selectedItems.includes("reel") ? [{ id:"reel", text:`${content.reel.postText} ${cta}.`, media:[ref("reel.mp4")], deliveryMedia:[ref("reel.mp4")], videoSpec:{width:1080,height:1920,durationSec:15}, burnedInCaptions:content.reel.captions.map(c=>c.text) }] : [])];
for (const it of items) { if (!it.text?.trim()) throw new Error(`missing final caption for ${it.id}`); if (!it.deliveryMedia?.length) throw new Error(`deliveryMedia empty for ${it.id}`); for (const m of it.deliveryMedia) if (!it.media.includes(m)) throw new Error(`deliveryMedia ${m} not in review media for ${it.id}`); }
const IDEM_F = path.join(OUT, "idempotency.json"); const idem = fs.existsSync(IDEM_F) ? JSON.parse(fs.readFileSync(IDEM_F,"utf8")) : {};
for (const it of items) { const k = `${BUNDLE_ID}@${VERSION}#${it.id}`; idem[k] ??= crypto.randomUUID(); }
fs.writeFileSync(IDEM_F, JSON.stringify(idem,null,2)+"\n");
const shots = (arg("--shots","site-snapshot.png,site-quote.png")).split(",").map(ref);
const EXTRA = arg("--source-json") ? JSON.parse(fs.readFileSync(arg("--source-json"),"utf8")) : null;
const mediaHashes = Object.fromEntries([...items.flatMap(i=>[...i.media,...i.deliveryMedia]), ...shots].map(m=>[m, sha(path.resolve(OUT, m))]));
const b = { bundleId:BUNDLE_ID, version:VERSION, versionCreatedAt:new Date().toISOString(), canonicalSources:[`clients/${client}/brand.json`,`clients/${client}/content.json`], mode:"DRY_RUN",
 business:`Client: ${name} — prepared by our agency`,
 websiteBrief:{ name, type:brandTokens.business?.type, audience:brandTokens.business?.audience, tagline:content.tagline, cta:content.cta,
   services:content.services.map(s=>`${s.name}: ${s.summary}`), serviceArea:content.serviceArea?.primary,
   pages:["/ (home: hero, services, FAQ, CTA)",`${content.cta.href} (${cta} form)`], screenshots:shots,
   unset:"prices, testimonials, licenses, insurance, discounts, contact details — intentionally not claimed" },
 items, mediaHashes,
 destinations:[ { platform:"<PLATFORM>", client, zernioAccountId:`<${PH}_ZERNIO_ACCOUNT_ID>`, profileId:`<${PH}_ZERNIO_PROFILE_ID>` } ],
 requireDeliveryMedia:true, idempotencyKeys:Object.fromEntries(items.map(it=>[it.id, idem[`${BUNDLE_ID}@${VERSION}#${it.id}`]])), scheduledTime:null, approval:null, ...(EXTRA ? { sourceVersion:EXTRA.sourceVersion, destinationStatus:EXTRA.destinationStatus } : {}) };
const BJ = path.join(OUT, "bundle.json");
fs.writeFileSync(BJ, JSON.stringify(b,null,2)+"\n");
const hash = execFileSync("node",[path.join(HERE,"approval-hash.mjs"), BJ]).toString().trim();
b.approvalHashExpected = hash; fs.writeFileSync(BJ, JSON.stringify(b,null,2)+"\n");
const esc=s=>String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const dest = b.destinations.map(d=>`${d.platform} / account ${d.zernioAccountId} / profile ${d.profileId} (client ${d.client})`).join("; ");
const wb=b.websiteBrief;
let md = `# Review bundle: ${b.bundleId} (${b.version}) — MODE: DRY RUN\nBusiness: ${b.business}\nWebsite snapshot: ${shots[0]} · Quote form: ${shots[1]}\n\n## Website brief\n- ${name}: ${wb.type} for ${wb.audience}\n- Tagline: ${wb.tagline}\n- CTA: ${cta} → ${content.cta.href}\n${wb.services.map(s=>"- "+s).join("\n")}\n- Service area: ${wb.serviceArea}\n- Not claimed: ${wb.unset}\n\n![site](${shots[0]}) ![quote](${shots[1]})\n\n| # | Item | Final text | Media (sha256) |\n|---|------|-----------|-------|\n`;
items.forEach((it,i)=>md+=`| ${i+1} | ${it.id} | ${it.text} | ${it.media.map(m=>`${it.deliveryMedia.includes(m)?"**DELIVER** ":"review-alt "}${m} (\`${mediaHashes[m].slice(0,12)}…\`)`).join("<br>")} |\n`);
const reel = items.find(it=>it.videoSpec);
md += (reel ? `\nReel: ${reel.videoSpec.width}x${reel.videoSpec.height}, ${reel.videoSpec.durationSec} s; burned-in captions: ${reel.burnedInCaptions.join(" / ")}\n` : "\nNo video is included in this review version.\n") + `\n## Media sha256\n${Object.entries(mediaHashes).map(([k,v])=>`- ${k}: \`${v}\``).join("\n")}\n\nDestinations: ${dest}   (placeholders until an account/profile is chosen)\nDestinations must be ${name} profile/accounts only.\n${EXTRA?"## Source version / status\n```json\n"+JSON.stringify(EXTRA,null,2)+"\n```\n\n":""}Scheduled time: none — scheduling is a separate later decision\nApproval hash (sha256 of bundleId + version + text + media bytes + destinations + time): \`${hash}\`\nApproval status: NOT APPROVED\n\nTo approve EXACTLY this version, reply: \`APPROVE ${hash}\`\nAny edit to any item, media, destination or time produces a new hash and voids this approval.\nApproval authorizes ONLY Zernio draft creation (omit scheduledFor and publishNow). It does not schedule or publish.\n`;
fs.writeFileSync(path.join(OUT,"review-bundle.md"), md);
const tag=m=>m.endsWith(".mp4")?`<video src="${m}" controls width="270"></video>`:`<img src="${m}" width="240">`;
fs.writeFileSync(path.join(OUT,"review-bundle.html"), `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${b.bundleId} ${b.version}</title><style>img,video{max-width:100%;height:auto}body{padding:0 16px;font-family:Inter,system-ui,sans-serif;background:#FFF7ED;color:#1C1917;max-width:1100px;margin:2em auto}table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:8px;vertical-align:top}code{word-break:break-all}.dry{background:#C2410C;color:#fff;padding:4px 10px;border-radius:8px}</style></head><body>
<h1>Review bundle: ${esc(b.bundleId)} (${b.version}) <span class="dry">DRY RUN — NOT SENT</span></h1><p>${esc(b.business)}</p>
<h2>Website brief</h2><ul><li>${esc(wb.type)} for ${esc(wb.audience)}</li><li>Tagline: ${esc(wb.tagline)}</li><li>CTA: ${esc(cta)} → ${esc(content.cta.href)}</li>${wb.services.map(s=>`<li>${esc(s)}</li>`).join("")}<li>Not claimed: ${esc(wb.unset)}</li></ul>
${shots.map(s=>`<img src="${s}" width="480">`).join(" ")}
<h2>Items</h2><table><tr><th>#</th><th>Item</th><th>Final text</th><th>Media</th></tr>${items.map((it,i)=>`<tr><td>${i+1}</td><td>${it.id}</td><td>${esc(it.text)}</td><td>${it.media.map(m=>tag(m)+`<br><small><b>${it.deliveryMedia.includes(m)?"DELIVER":"review alternative (not delivered)"}</b> ${m}<br><code>${mediaHashes[m]}</code></small>`).join("<br>")}</td></tr>`).join("")}</table>
<p>Website screenshots: ${shots.join(", ")}</p><p>Destinations: ${esc(dest)} (placeholders; ${esc(name)} only)</p>${EXTRA?`<h2>Source version / status</h2><pre>${esc(JSON.stringify(EXTRA,null,2))}</pre>`:""}<p>Scheduled time: none</p>
<p>Approval hash: <code>${hash}</code> — status: NOT APPROVED</p><p>To approve exactly this version reply <code>APPROVE ${hash}</code>. Approval authorizes only Zernio draft creation (omit scheduledFor and publishNow); no scheduling, no publishing.</p></body></html>`);
const files=[];
for (const it of items){ const key=b.idempotencyKeys[it.id]; const r={ _status:"NOT SENT — DRY RUN. Placeholders only. Never sent; no network call made.",
  _client:`${client}. Never use Ship AI / agency destinations.`, _bundle:`${b.bundleId}@${b.version}`, _item:it.id, _approvalHash:hash, _approved:false,
  _destinationStatus: b.destinationStatus ?? "placeholders", _localMedia: it.deliveryMedia.map(m=>({path:m, sha256:mediaHashes[m], uploadAs:`<PRESIGNED_PUBLIC_URL_${m.split("/").pop()}>`})),
  _docs:"https://docs.zernio.com/ (isDraft true; omit scheduledFor and publishNow; media must be public HTTPS URLs via POST /v1/media/presign). Re-check before any real send.",
  method:"POST", url:"https://zernio.com/api/v1/posts",
  headers:{ Authorization:"Bearer <ZERNIO_API_KEY from env/secret store at send time — never pasted in chat>", "Content-Type":"application/json", "Idempotency-Key":key },
  body:{ isDraft:true, content:it.text, mediaItems:it.deliveryMedia.map(m=>({type:m.endsWith(".mp4")?"video":"image",url:`<PRESIGNED_PUBLIC_URL_${m.split("/").pop()}>`})),
    platforms:b.destinations.map(d=>({platform:d.platform,accountId:d.zernioAccountId})), metadata:{client,approvalHash:hash,bundleVersion:b.version,item:it.id} },
  _omitted_on_purpose:["scheduledFor","publishNow","queuedFromProfile"] };
 const f=path.join(OUTBOX,`NOT_SENT-${b.bundleId}-${it.id}.json`); fs.writeFileSync(f,JSON.stringify(r,null,2)+"\n"); files.push(f); }
console.log(JSON.stringify({bundle:BJ, version:VERSION, hash, approved:false, outbox:files}, null, 1));
