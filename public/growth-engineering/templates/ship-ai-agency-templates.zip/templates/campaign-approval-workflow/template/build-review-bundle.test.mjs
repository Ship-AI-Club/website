import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';

const here=path.dirname(fileURLToPath(import.meta.url));
const kit=path.resolve(here,'../../..');
const reference=path.resolve(here,'../example/desert-shine/media');

function fixture(t, modern=false) {
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'ship-ai selected media '));
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  fs.mkdirSync(path.join(root,'clients'),{recursive:true});
  fs.cpSync(path.join(kit,'clients/desert-shine'),path.join(root,'clients/desert-shine'),{recursive:true});
  if(!modern) { const f=path.join(root,'clients/desert-shine/content.json'); const c=JSON.parse(fs.readFileSync(f));delete c.socialCreatives;delete c.video;fs.writeFileSync(f,JSON.stringify(c)); }
  fs.mkdirSync(path.join(root,'media'));
  for(const name of ['post-1-Social4x5.png','site-snapshot.png','site-quote.png']) fs.copyFileSync(path.join(reference,name),path.join(root,'media',name));
  const run=(items)=>spawnSync(process.execPath,[path.join(here,'build-review-bundle.mjs'),'--project',root,'--media',path.join(root,'media'),'--out',path.join(root,'review'),'--outbox',path.join(root,'outbox'),'--copy-media','--items',items],{encoding:'utf8'});
  return {root,run};
}

test('review one static without requiring unapproved variants or video',t=>{
  const {root,run}=fixture(t);const result=run('post-1');
  assert.equal(result.status,0,result.stderr);
  const bundle=JSON.parse(fs.readFileSync(path.join(root,'review/bundle.json')));
  assert.deepEqual(bundle.items.map(item=>item.id),['post-1']);
  assert.equal(bundle.items[0].media.length,1);
  assert.deepEqual(bundle.items[0].deliveryMedia,bundle.items[0].media);
  assert.equal(bundle.approval,null);
  const requests=fs.readdirSync(path.join(root,'outbox'));
  assert.equal(requests.length,1);
  const request=JSON.parse(fs.readFileSync(path.join(root,'outbox',requests[0])));
  assert.equal(request.body.isDraft,true);
  assert.equal(request.body.mediaItems.length,1);
  assert.match(fs.readFileSync(path.join(root,'review/review-bundle.md'),'utf8'),/No video is included/);
  const key=request.headers['Idempotency-Key'];
  assert.equal(run('post-1').status,0);
  assert.equal(JSON.parse(fs.readFileSync(path.join(root,'outbox',requests[0]))).headers['Idempotency-Key'],key);
});

test('selected video must exist and is included once supplied',t=>{
  const {root,run}=fixture(t);
  assert.notEqual(run('post-1,reel').status,0);
  fs.copyFileSync(path.join(reference,'reel.mp4'),path.join(root,'media/reel.mp4'));
  const result=run('post-1,reel');assert.equal(result.status,0,result.stderr);
  const bundle=JSON.parse(fs.readFileSync(path.join(root,'review/bundle.json')));
  assert.deepEqual(bundle.items.map(item=>item.id),['post-1','reel']);
  assert.equal(bundle.items[1].deliveryMedia.length,1);
});

test('unknown, duplicate and empty item selections are rejected',t=>{
  const {run}=fixture(t);
  for(const selection of ['unknown','post-1,post-1','']) assert.notEqual(run(selection).status,0,selection);
});

// Modern photo/video creatives must use their exact final captions, not legacy demo copy.
test('modern bundle preserves reviewed media and captions; approval detects later changes',t=>{
 const {root,run}=fixture(t,true);
 const current=path.resolve(here,'../example/desert-shine-redesign/media');
 for(const name of ['social-v1.png','video-v1.mp4']) fs.copyFileSync(path.join(current,name),path.join(root,'media',name));
 const result=run('social-v1,video-v1');assert.equal(result.status,0,result.stderr);
 const file=path.join(root,'review/bundle.json');const b=JSON.parse(fs.readFileSync(file));
 const c=JSON.parse(fs.readFileSync(path.join(root,'clients/desert-shine/content.json')));
 assert.equal(b.items[0].text,c.socialCreatives[0].caption);assert.equal(b.items[1].text,c.video.reels[0].caption);
 for(const name of ['social-v1.png','video-v1.mp4']) assert.deepEqual(fs.readFileSync(path.join(root,'review/media',name)),fs.readFileSync(path.join(current,name)));
 const hash=()=>spawnSync(process.execPath,[path.join(here,'approval-hash.mjs'),file,'--check'],{encoding:'utf8'});
 assert.equal(hash().status,1);b.approval={hash:b.approvalHashExpected,approvedBy:'SIMULATED_ONLY'};fs.writeFileSync(file,JSON.stringify(b));assert.equal(hash().status,0);
 b.items[1].text+=' edit';fs.writeFileSync(file,JSON.stringify(b));assert.equal(hash().status,1);
 b.items[1].text=c.video.reels[0].caption;fs.writeFileSync(file,JSON.stringify(b));assert.equal(hash().status,0);
 fs.appendFileSync(path.join(root,'review/media/video-v1.mp4'),'changed');assert.equal(hash().status,1);
});
