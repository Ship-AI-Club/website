# Review bundle: {{bundleId}}  — MODE: DRY RUN
Business: {{business}} (fictional demo)
Website snapshot: {{siteSnapshotPath}}

| # | Item | Final text | Media | 
|---|------|-----------|-------|
{{#items}}| {{id}} | {{text}} | {{media}} |
{{/items}}

Destinations: {{destinations}}   (placeholders until an account/profile is chosen)
Destinations must be Desert Shine profile/accounts only.
Scheduled time: {{scheduledTime | "none — scheduling is a separate later decision"}}
Approval hash (sha256 of text + media bytes + destinations + time): `{{hash}}`

To approve EXACTLY this version, reply: `APPROVE {{hash}}`
Any edit to any item, media, destination or time produces a new hash and voids this approval.
Approval authorizes ONLY Zernio draft creation (isDraft:true). It does not schedule or publish.
