# DISABLED routine template — Ship AI Demo weekly content (DO NOT ACTIVATE)
status: DISABLED
precondition: manual path proven end-to-end at least once (site → stills → reel → review bundle → exact-hash approval → Zernio draft). Not yet proven.
schedule: <unset>
steps:
1. Campaign Manager runs @ship-ai-demo-campaign-orchestrator in DRY RUN for <business data file>.
2. Produce review bundle + approval hash; stop and wait for human `APPROVE <hash>`.
3. No drafts, schedules or publishing happen from the routine itself.
Activation requires Santos's explicit decision in a later session. Never created via UpdateRoutine in this kit.
