# Client Website (v2): Ship AI agency template

First run: see `SETUP.md`. Workflow: see `SKILL.md`. Next.js **15.5.20** (pinned in `package.json` and `package-lock.json`).

Editorial Next.js (App Router) client site: nav, 45/55 hero with a large photo, services, how it works, service area, FAQ, final CTA, footer with a discreet demo note. `/quote` has client-side validation and a local "request prepared, nothing sent" summary. Nothing is sent over the network.

**No client data lives here.** Copy and tokens are read at build time from `$CLIENTS_DIR/<client>/brand.json` + `content.json`. Images are copied from `$ASSETS_DIR` into `public/assets/` by `scripts/sync-assets.mjs` (this runs as `prebuild`).

## Inputs
| Env | Default | Meaning |
|---|---|---|
| `NEXT_PUBLIC_CLIENT` | `_template` (always set it) | client slug |
| `CLIENTS_DIR` | `../../clients` (relative to `template/`) | canonical client folder |
| `ASSETS_DIR` | `../../assets` | client images/SVGs, copied into `public/assets/` (subfolders kept; files starting `_` skipped) |
| `STATIC_EXPORT` | unset | `1` = static export to `out/` |
| `NEXT_PUBLIC_BASE_PATH` | `""` normally; in export `/growth-engineering/<NEXT_PUBLIC_CLIENT>` (Desert Shine → `/growth-engineering/desert-shine`) | basePath + assetPrefix |

Images: paths, alt text and `object-position` focal points all live in `content.json` (`site.hero.image.desktop|mobile`, `site.servicesImage`, `site.areaImage`). The hero uses `<picture>`: `mobile` under `mobileMaxWidth` (900px), `desktop` above it. **Swap the hero:** change `site.hero.image.desktop.src` (one line), or replace `assets/img/hero-home.jpg`, then rebuild. Logo (`brand.logo.lockup`) and service/step icons (`services[].icon`, `site.how.steps[].icon`) are SVGs inlined at build time, so the lockup's live text uses the self-hosted font and icons inherit `currentColor`. Photo credit: Pexels photo 34960819 and others listed in `assets/SOURCES.md` (Pexels License). It's shown discreetly in the footer through `site.credits`.

## Normal mode (from `template/`)
```bash
npm ci && NEXT_PUBLIC_CLIENT=desert-shine npm run build && NEXT_PUBLIC_CLIENT=desert-shine npx next start -p 3300
```

## Static export (from `template/`)
```bash
npm ci && NEXT_PUBLIC_CLIENT=desert-shine npm run build:export
```
(`build:export` = sync assets + `STATIC_EXPORT=1 next build`. Normal mode builds into `.next-start/`. Export uses `.next/` as scratch and writes `out/`, so it never touches a running `next start`. `NEXT_DIST_DIR` overrides the normal-mode dir.) A prebuilt copy ships in `<root>/export/growth-engineering/desert-shine/`. Output: `template/out/` with `index.html` and `quote/index.html` (trailingSlash). All asset URLs sit under `/growth-engineering/desert-shine`. Mount `out/` at `https://www.shipai.club/growth-engineering/desert-shine/`. Links are plain `<a>` tags with the base path prefix, so navigation doesn't rely on the Next router. Images are unoptimized in both modes.

## Content contract
`content.json` must provide `tagline`, `cta`, `services[]`, `serviceArea`, `faq[]` and `site.{metaTitle, metaDescription, footerNote, nav[], hero, servicesHeading, servicesIntro, how, areaHeading, faqHeading, finalCta, quote}`. See `clients/desert-shine/content.json`. `brand.json` provides `business.name` and `tokens.{colors.{navy,sky,sunflower,slate,white}, font, radius}`. The font is self-hosted through `@fontsource/plus-jakarta-sans`.

Never fabricate prices, testimonials, ratings, insurance, staff, guarantees, phone numbers or addresses. No deploys without approval.

## Behaviour notes
- Only the hero image loads eagerly with high fetch priority; all other photos lazy-load.
- `/quote/?service=<id>` preselects that service on the client side, so it also works in the static export. Service links come from `services[].ctaHref`.
- Mobile nav is a no-JS `<details>` menu. At 390px the header CTA moves into the menu.
- On desktop (≥1024px) the hero headline renders as one nowrap line per `site.hero.headlineLines` entry.
- `sync-assets` validates `ASSETS_DIR` first and copies through a temp dir. A missing source exits 1 and keeps the last good `public/assets`.


## Full agency kit paths
Run from kit root (all templates share the same client and licensed assets):
```bash
cd templates/client-website/template
npm ci
CLIENTS_DIR=../../../clients ASSETS_DIR=../../../assets NEXT_PUBLIC_CLIENT=desert-shine npm run build
CLIENTS_DIR=../../../clients ASSETS_DIR=../../../assets NEXT_PUBLIC_CLIENT=desert-shine npm run start
```
For the static export use the same variables with `npm run build:export`. Quote submission prepares an on-page demo summary and sends nothing.
