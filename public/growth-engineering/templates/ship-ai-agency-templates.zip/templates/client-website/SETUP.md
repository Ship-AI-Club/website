# First run (about 2 minutes)

Requires Node 20+ and npm, and no network access beyond `npm ci`. Unzip anywhere and keep this layout:

```
<root>/client-website/template   site source (run commands here)
<root>/clients/<slug>/           brand.json + content.json (canonical copy/tokens)
<root>/assets/                   images, SVG logo/icons, fonts/, SOURCES.md (licenses)
<root>/export/growth-engineering/desert-shine/   prebuilt static export (Desert Shine)
<root>/shots/                    review screenshots (r1–r3)
```

```bash
cd client-website/template
npm ci
# preview (normal mode) at http://localhost:3300
NEXT_PUBLIC_CLIENT=desert-shine npm run build && NEXT_PUBLIC_CLIENT=desert-shine npx next start -p 3300
# static export -> out/ (base path /growth-engineering/desert-shine)
NEXT_PUBLIC_CLIENT=desert-shine npm run build:export
```

`CLIENTS_DIR` and `ASSETS_DIR` default to `../../clients` and `../../assets`. Set them to use other folders. If `ASSETS_DIR` is missing, the build stops with a clear error and leaves `public/assets` untouched.
Try other clients with `NEXT_PUBLIC_CLIENT=sample-client` or `NEXT_PUBLIC_CLIENT=_template`. They have no photos; point `ASSETS_DIR` at any folder, even an empty one.
To preview the export locally, serve `out/` under `/growth-engineering/desert-shine/` with any static server.
