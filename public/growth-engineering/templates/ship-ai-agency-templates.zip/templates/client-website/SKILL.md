---
name: client-website-v2
description: Build, preview and statically export an agency client marketing site (home + demo /quote) from canonical client JSON. Rehearsed with Desert Shine (fictional).
---
Read `README.md` and `SETUP.md` first. We are the agency; the site belongs to the client.

1. Get the client slug and approved brief. Read `clients/<client>/{brand,content}.json`. All copy, tokens, image paths, alt text and focal points live there; components hold no client copy. New client: `cp -r clients/_template clients/<slug>`. Keep unknown facts `null` and out of copy. Never invent prices, testimonials, ratings, insurance, staff, guarantees, phone numbers or addresses.
2. Put images and SVGs in `assets/`, with source and license in `assets/SOURCES.md`. Change the hero by editing `site.hero.image.desktop.src` (one line).
3. From `client-website/template`: run `npm ci`, then the normal or export command in README. The two modes use separate build dirs (`.next-start`, and `.next` plus `out/`).
4. Inspect `/` and `/quote/` at 1440 and 390: overflow, focus, quote errors, `?service=` preselect, and the honest "nothing was sent" summary. Run the acceptance QA if you have it.
5. Report build results and missing client inputs. The quote form stays demo-only. No deploy without the owner's instruction.
