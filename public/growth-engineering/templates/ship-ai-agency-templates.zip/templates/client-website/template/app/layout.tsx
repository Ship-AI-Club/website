import "@fontsource/plus-jakarta-sans/400.css";
import "@fontsource/plus-jakarta-sans/600.css";
import "@fontsource/plus-jakarta-sans/800.css";
import "./globals.css";
import { brand, content } from "../lib/client";
import { Header, Footer } from "../components/Chrome";
export const metadata = { title: content.site.metaTitle, description: content.site.metaDescription ?? content.tagline };
export const viewport = { width: "device-width", initialScale: 1 };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  const c = brand.tokens.colors;
  const vars = { "--navy": c.navy ?? c.text, "--sky": c.sky ?? c.background, "--sunflower": c.sunflower ?? c.accent, "--slate": c.slate ?? c.secondary, "--white": c.white ?? "#fff", "--font": brand.tokens.font, "--radius": `${brand.tokens.radius}px` } as React.CSSProperties;
  const s = content.site;
  return (<html lang="en" style={vars}><body>
    <a className="skip" href="#main">Skip to content</a>
    <Header name={brand.business.name} logo={brand.logo?.lockup} nav={s.nav} cta={content.cta} menuLabel={s.menuLabel ?? "Menu"} />
    <main id="main">{children}</main>
    <Footer name={brand.business.name} logo={brand.logo?.lockup} note={s.footerNote} credits={s.credits} nav={s.nav} />
  </body></html>);
}
