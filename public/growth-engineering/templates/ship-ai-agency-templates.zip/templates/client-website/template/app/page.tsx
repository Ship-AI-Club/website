/* eslint-disable @next/next/no-img-element */
import { content } from "../lib/client";
import { href, asset } from "../lib/href";
import { svg } from "../lib/assets";
type Img = { src: string; width: number; height: number; alt: string; position?: string };
function Photo({ img, className, eager }: { img: Img; className?: string; eager?: boolean }) {
  return <img className={className} src={asset(img.src)} alt={img.alt} width={img.width} height={img.height}
    style={{ objectPosition: img.position }} loading={eager ? "eager" : "lazy"} {...(eager ? { fetchPriority: "high" as const } : {})} decoding="async" />;
}
const Icon = ({ file }: { file?: string }) => file ? <span className="icon" dangerouslySetInnerHTML={{ __html: svg(file, { decorative: true }) }} /> : null;
export default function Home() {
  const s = content.site, h = s.hero, hi = h.image;
  return (<>
    <section className="hero"><div className={`wrap hero-grid${hi ? "" : " no-media"}`}>
      <div className="hero-copy">
        {h.eyebrow && <p className="eyebrow">{h.eyebrow}</p>}
        <h1>{h.headlineLines ? h.headlineLines.map((l: string, i: number) => <span key={i} className="line">{l}</span>) : h.headline}</h1>
        <p className="lead">{h.body}</p>
        <div className="actions">
          <a className="btn btn-primary" href={href(h.primaryCta.href)}>{h.primaryCta.label}</a>
          {h.secondaryCta && <a className="btn btn-ghost" href={href(h.secondaryCta.href)}>{h.secondaryCta.label}</a>}
        </div>
      </div>
      {hi && <div className="hero-media" style={{ ["--pos-d" as any]: hi.desktop.position, ["--pos-m" as any]: hi.mobile?.position ?? hi.desktop.position }}>
        <picture>
          {hi.mobile && <source media={`(max-width: ${hi.mobileMaxWidth ?? 900}px)`} srcSet={asset(hi.mobile.src)} width={hi.mobile.width} height={hi.mobile.height} />}
          <Photo img={{ ...hi.desktop, position: undefined }} eager />
        </picture>
        {h.inset && <div className="hero-inset"><Photo img={h.inset} /></div>}
      </div>}
    </div></section>

    <section id="services" className="section"><div className="wrap">
      <div className="section-head"><h2>{s.servicesHeading}</h2><p>{s.servicesIntro}</p></div>
      <ol className="services">{content.services.map((sv: any, i: number) => (
        <li key={sv.id} className={`service${i % 2 ? " flip" : ""}`}>
          {sv.image && <Photo img={sv.image} className="service-img" />}
          <div className="service-body">
            <Icon file={sv.icon} /><h3>{sv.name}</h3><p>{sv.summary}</p>
            {sv.details && <ul className="ticks">{sv.details.map((d: string) => <li key={d}>{d}</li>)}</ul>}
            {sv.ctaHref && <a className="text-link" href={href(sv.ctaHref)}>{sv.ctaLabel} <span aria-hidden="true">→</span></a>}
          </div>
        </li>))}</ol>
    </div></section>

    <section id="how" className="section section-sky"><div className="wrap">
      <div className="section-head"><h2>{s.how.heading}</h2></div>
      <ol className="steps">{s.how.steps.map((st: any, i: number) => (
        <li key={st.title}><div className="step-top"><Icon file={st.icon} /><span className="step-n">{i + 1}</span></div><h3>{st.title}</h3><p>{st.body}</p></li>))}</ol>
    </div></section>

    <section id="area" className="section"><div className="wrap area">
      <div><h2>{s.areaHeading}</h2><p className="area-city">{content.serviceArea.primary}</p><p className="muted">{content.serviceArea.notes}</p></div>
      {s.areaImage && <Photo img={s.areaImage} className="area-img" />}
    </div></section>

    <section id="faq" className="section section-sky"><div className="wrap faq-wrap">
      <h2>{s.faqHeading}</h2>
      <div className="faq">{content.faq.map((f: any) => (<details key={f.q}><summary>{f.q}</summary><p>{f.a}</p></details>))}</div>
    </div></section>

    <section className="final"><div className="wrap final-row">
      <div><h2>{s.finalCta.heading}</h2><p>{s.finalCta.body}</p></div>
      <a className="btn btn-primary" href={href(s.finalCta.href)}>{s.finalCta.label}</a>
    </div></section>
  </>);
}
