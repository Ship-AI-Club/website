"use client";
import { useEffect, useRef, useState } from "react";
import { href } from "../../lib/href";
type Q = any;
type Vals = { name: string; email: string; zip: string; service: string; timing: string; details: string };
const empty: Vals = { name: "", email: "", zip: "", service: "", timing: "", details: "" };
function validate(v: Vals, e: Q["errors"]) {
  const out: Partial<Record<keyof Vals, string>> = {};
  if (v.name.trim().length < 2) out.name = e.name;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email.trim())) out.email = e.email;
  if (!/^\d{5}$/.test(v.zip.trim())) out.zip = e.zip;
  if (!v.service) out.service = e.service;
  if (!v.timing) out.timing = e.timing;
  if (v.details.trim().length < 10) out.details = e.details;
  return out;
}
export default function QuoteForm({ q, services }: { q: Q; services: { id: string; name: string }[] }) {
  const [v, setV] = useState<Vals>(empty);
  const [err, setErr] = useState<Partial<Record<keyof Vals, string>>>({});
  const [done, setDone] = useState(false);
  const [tried, setTried] = useState(false);
  const summaryRef = useRef<HTMLDivElement>(null);
  const f = q.fields;
  // Preselect ?service=<id> client-side (works in static export).
  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get("service");
    if (id && services.some(s => s.id === id)) setV(prev => ({ ...prev, service: id }));
  }, [services]);
  const set = (k: keyof Vals) => (ev: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const nv = { ...v, [k]: ev.target.value }; setV(nv); if (tried) setErr(validate(nv, q.errors));
  };
  function onSubmit(ev: React.FormEvent<HTMLFormElement>) {
    ev.preventDefault(); // Demo: no network submission.
    setTried(true);
    const e = validate(v, q.errors); setErr(e);
    const first = Object.keys(e)[0];
    if (first) { (document.getElementById(`f-${first}`) as HTMLElement | null)?.focus(); return; }
    setDone(true); setTimeout(() => summaryRef.current?.focus(), 0);
  }
  if (done) {
    const svc = services.find(s => s.id === v.service)?.name;
    const rows: [string, string][] = [[f.name, v.name], [f.email, v.email], [f.zip, v.zip], [f.service, svc ?? ""], [f.timing, v.timing], [f.details, v.details]];
    return (<div className="panel summary" ref={summaryRef} tabIndex={-1} role="status" aria-live="polite">
      <h2>{q.successHeading}</h2><p>{q.successBody}</p>
      <dl>{rows.map(([k, val]) => (<div key={k}><dt>{k}</dt><dd>{val}</dd></div>))}</dl>
      <div className="actions"><button type="button" className="btn btn-ghost" onClick={() => setDone(false)}>{q.edit}</button><a className="btn btn-primary" href={href("/")}>{q.back}</a></div>
    </div>);
  }
  const field = (k: keyof Vals, label: string, input: React.ReactNode, hint?: string) => (
    <div className={`field${err[k] ? " has-error" : ""}`}>
      <label htmlFor={`f-${k}`}>{label}</label>
      {hint && <p className="hint" id={`h-${k}`}>{hint}</p>}
      {input}
      {err[k] && <p className="error" id={`e-${k}`}>{err[k]}</p>}
    </div>);
  const a = (k: keyof Vals, hint?: boolean) => ({ id: `f-${k}`, name: k, value: v[k], onChange: set(k), "aria-invalid": !!err[k] || undefined,
    "aria-describedby": [hint ? `h-${k}` : "", err[k] ? `e-${k}` : ""].filter(Boolean).join(" ") || undefined });
  return (<form className="panel form" noValidate onSubmit={onSubmit}>
    {tried && Object.keys(err).length > 0 && <p className="form-alert" role="alert">{q.errors.summary}</p>}
    <div className="row2">
      {field("name", f.name, <input {...a("name")} autoComplete="name" required />)}
      {field("email", f.email, <input {...a("email")} type="email" autoComplete="email" required />)}
    </div>
    <div className="row2">
      {field("zip", f.zip, <input {...a("zip")} inputMode="numeric" autoComplete="postal-code" maxLength={5} required />)}
      {field("service", f.service, <select {...a("service")} required><option value="">{f.servicePlaceholder}</option>{services.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select>)}
    </div>
    {field("timing", f.timing, <select {...a("timing")} required><option value="">{f.timingPlaceholder}</option>{f.timingOptions.map((o: string) => <option key={o} value={o}>{o}</option>)}</select>)}
    {field("details", f.details, <textarea {...a("details", true)} rows={5} required />, f.detailsHint)}
    <button type="submit" className="btn btn-primary btn-block">{q.submit}</button>
  </form>);
}
