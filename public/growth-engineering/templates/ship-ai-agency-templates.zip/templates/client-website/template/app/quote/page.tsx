import { brand, content } from "../../lib/client";
import QuoteForm from "./QuoteForm";
export const metadata = { title: `${content.site.quote.heading} | ${brand.business.name}` };
export default function Quote() {
  const q = content.site.quote;
  return (<section className="section quote-page"><div className="wrap quote-grid">
    <div className="quote-intro"><h1>{q.heading}</h1><p className="lead">{q.intro}</p></div>
    <QuoteForm q={q} services={content.services.map((s: any) => ({ id: s.id, name: s.name }))} />
  </div></section>);
}
