import { href } from "../lib/href";
import { svg } from "../lib/assets";
type Link = { label: string; href: string };
function Brand({ name, logo, footer }: { name: string; logo?: string | null; footer?: boolean }) {
  const cls = `brand${footer ? " brand-footer" : ""}`;
  return logo ? <a className={cls} href={href("/")} aria-label={name} dangerouslySetInnerHTML={{ __html: svg(logo, { decorative: true }) }} />
    : <a className={`${cls} brand-text`} href={href("/")}>{name}</a>;
}
export function Header({ name, logo, nav, cta, menuLabel }: { name: string; logo?: string | null; nav: Link[]; cta: Link; menuLabel: string }) {
  return (<header className="site-header"><div className="wrap header-row">
    <Brand name={name} logo={logo} />
    <nav aria-label="Main"><ul className="nav-list">{nav.map(l => <li key={l.href}><a href={href(l.href)}>{l.label}</a></li>)}</ul></nav>
    <a className="btn btn-primary btn-sm header-cta" href={href(cta.href)}>{cta.label}</a>
    <details className="mnav"><summary>{menuLabel}</summary>
      <nav aria-label="Mobile"><ul>{nav.map(l => <li key={l.href}><a href={href(l.href)}>{l.label}</a></li>)}<li><a className="btn btn-primary" href={href(cta.href)}>{cta.label}</a></li></ul></nav>
    </details>
  </div></header>);
}
export function Footer({ name, logo, note, credits, nav }: { name: string; logo?: string | null; note: string; credits?: string; nav: Link[] }) {
  return (<footer className="site-footer"><div className="wrap footer-row">
    <Brand name={name} logo={logo} footer />
    <ul className="footer-nav">{nav.map(l => <li key={l.href}><a href={href(l.href)}>{l.label}</a></li>)}</ul>
    <p className="demo-note">{note}{credits ? <> {credits}</> : null}</p>
  </div></footer>);
}
