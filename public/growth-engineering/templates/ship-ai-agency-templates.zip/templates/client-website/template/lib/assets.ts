// Server-only: inline an SVG from ASSETS_DIR so live text uses the page font and icons inherit currentColor.
import fs from "node:fs"; import path from "node:path";
const dir = path.resolve(process.env.ASSETS_DIR || path.join(process.cwd(), "..", "..", "assets"));
export function svg(rel: string, opts: { decorative?: boolean } = {}): string {
  let s = fs.readFileSync(path.join(dir, rel), "utf8").replace(/<\?xml[^>]*>/, "").trim();
  s = s.replace(/<svg([^>]*?)\swidth="[^"]*"/, "<svg$1").replace(/<svg([^>]*?)\sheight="[^"]*"/, "<svg$1");
  if (opts.decorative) s = s.replace(/\srole="img"/, "").replace(/\saria-label="[^"]*"/, "").replace(/<title>.*?<\/title>/, "").replace("<svg", '<svg aria-hidden="true" focusable="false"');
  return s;
}
