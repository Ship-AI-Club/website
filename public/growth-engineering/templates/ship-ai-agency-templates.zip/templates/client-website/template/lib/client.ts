// Loads clients/<slug>/brand.json + content.json from CLIENTS_DIR at build time. No client data lives in this template.
import fs from "node:fs";
import path from "node:path";
/* eslint-disable @typescript-eslint/no-explicit-any */
export type Brand = any;
export type Content = any;
export const CLIENT = process.env.NEXT_PUBLIC_CLIENT || "_template";
function load(id: string): { brand: Brand; content: Content } {
  if (!/^[a-z0-9_-]+$/.test(id)) throw new Error(`Invalid client slug "${id}"`);
  const clientsDir = path.resolve(process.env.CLIENTS_DIR || path.join(process.cwd(), "..", "..", "clients"));
  const dir = path.join(clientsDir, id);
  if (!fs.existsSync(dir)) throw new Error(`Unknown client "${id}": expected ${dir}/brand.json and content.json (set CLIENTS_DIR)`);
  const read = (f: string) => JSON.parse(fs.readFileSync(path.join(dir, f), "utf8"));
  return { brand: read("brand.json"), content: read("content.json") };
}
export const { brand, content } = load(CLIENT);
