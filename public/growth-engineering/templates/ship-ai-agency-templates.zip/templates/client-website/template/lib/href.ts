// Plain-anchor URLs that work in both modes (basePath prefix + trailing slash, query/hash kept). Safe in client components.
const BASE = process.env.NEXT_PUBLIC_BASE_PATH || "";
export function href(h: string): string {
  if (/^(https?:|mailto:|tel:)/.test(h) || h.startsWith("#")) return h;
  const m = h.match(/^([^?#]*)(\?[^#]*)?(#.*)?$/)!;
  let p = m[1] || "/";
  if (!p.endsWith("/")) p += "/";
  return `${BASE}${p}${m[2] ?? ""}${m[3] ?? ""}`;
}
export const asset = (f: string) => `${BASE}/assets/${f}`;
