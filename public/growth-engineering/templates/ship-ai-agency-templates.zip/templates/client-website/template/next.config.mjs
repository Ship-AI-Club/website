// Normal mode: `next build && next start` (basePath from NEXT_PUBLIC_BASE_PATH, default "").
// Static export: STATIC_EXPORT=1 -> output "export" into out/, basePath+assetPrefix default "/growth-engineering/<NEXT_PUBLIC_CLIENT>" (e.g. /growth-engineering/<slug>).
const isExport = process.env.STATIC_EXPORT === "1";
const base = (process.env.NEXT_PUBLIC_BASE_PATH ?? (isExport ? `/growth-engineering/${process.env.NEXT_PUBLIC_CLIENT || "_template"}` : "")).replace(/\/$/, "");
export default {
  trailingSlash: true,
  // Separate build dirs: normal -> .next-start (served by `next start`); export -> intermediate .next + final out/.
  ...(isExport ? { output: "export", distDir: "out" } : { distDir: process.env.NEXT_DIST_DIR || ".next-start" }),
  ...(base ? { basePath: base, assetPrefix: base } : {}),
  images: { unoptimized: true },
  env: { NEXT_PUBLIC_BASE_PATH: base },
};
