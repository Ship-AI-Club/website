// Copies client images/icons from ASSETS_DIR (default ../../assets) into public/assets/ (subfolders kept, "_" files skipped).
// Safe: validates the source first, copies into a temp dir, then swaps. A bad ASSETS_DIR never destroys the last good public/assets.
import fs from "node:fs"; import path from "node:path";
const root = process.cwd();
const assets = path.resolve(process.env.ASSETS_DIR || path.join(root, "..", "..", "assets"));
const dest = path.join(root, "public", "assets");
const fail = (m) => { console.error(`[sync-assets] ERROR: ${m}. public/assets left unchanged.`); process.exit(1); };
if (!fs.existsSync(assets)) fail(`ASSETS_DIR not found: ${assets} (set ASSETS_DIR to the client's assets folder)`);
if (!fs.statSync(assets).isDirectory()) fail(`ASSETS_DIR is not a directory: ${assets}`);
const tmp = path.join(root, "public", `.assets-tmp-${process.pid}`);
fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true });
let n = 0;
try {
  (function walk(rel) {
    for (const e of fs.readdirSync(path.join(assets, rel), { withFileTypes: true })) {
      const r = path.join(rel, e.name);
      if (e.isDirectory()) walk(r);
      else if (/\.(jpe?g|png|webp|avif|svg)$/i.test(e.name) && !e.name.startsWith("_")) { fs.mkdirSync(path.join(tmp, rel), { recursive: true }); fs.copyFileSync(path.join(assets, r), path.join(tmp, r)); n++; }
    }
  })("");
} catch (err) { fs.rmSync(tmp, { recursive: true, force: true }); fail(`copy failed: ${err.message}`); }
const old = `${dest}.old-${process.pid}`;
if (fs.existsSync(dest)) fs.renameSync(dest, old);
fs.renameSync(tmp, dest);
fs.rmSync(old, { recursive: true, force: true });
console.log(`[sync-assets] copied ${n} files from ${assets}`);
