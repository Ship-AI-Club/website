# Ship AI · short-video

Read `BUILD-YOUR-AI-MARKETING-TEAM.md` at kit root. This template is the actual Grok Bot source used in the improved Desert Shine demo. Shared copy and assets live at kit root in `clients/` and `assets/`.

Run from kit root:
```bash
cd templates/short-video/template && npm ci && node render-reel.mjs --clients ../../../clients --assets ../../../assets --client desert-shine --reel video-v1 --out ../../../out --name video-v1.mp4
```

Node 20+ and npm required. Remotion downloads a browser on first render. Fonts and photo licenses are bundled. Render one static first and repeat feedback until approved. Research and approve the video concept before rendering; review the full video and caption afterward. Neither renderer uploads or posts.

The `template/README.md` documents composition inputs and flags; use the explicit shared paths above in this kit. For another client, replace the client JSON, logo and licensed photos.
