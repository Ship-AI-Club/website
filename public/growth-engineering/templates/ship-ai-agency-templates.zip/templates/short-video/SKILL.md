---
name: Ship AI Demo · Client 15s reel
description: >-
  Render a 15-second 1080x1920 Remotion video with captions and CTA from the
  client's canonical content.json/brand.json. Use when asked for a client reel.
---

# Client 15s vertical reel (PhotoReel method, v1 · Oct 14 2026)
Input: `client` (default `desert-shine`). Template: `/workspace/ship-ai-demo/templates/short-video/template/` (self-contained: package.json + lockfile, bundled Plus Jakarta Sans woff2 + OFL, `render-reel.mjs`, `src/PhotoReel.tsx`; legacy text-only `Reel.tsx` kept).

## Inputs (single source of truth, re-read every run; Site Builder edits them)
- `clients/<client>/brand.json` tokens (navy/sky/sunflower/slate/white, radius) + `logo.markOnDark`.
- `clients/<client>/content.json`: `services[]` and an additive `video.reels[]` key holding ALL reel copy and the scene plan (`photo` / `services` / `endcard`, from/to seconds, image + focal `position`, motion push|pan|drift, `posterSec`, caption, alt). Never put copy in the composition. Only approved facts: no prices, reviews, guarantees, staff or invented claims.
- Assets: client assets folder (img/, icons/, brand/) passed as Remotion publicDir; licensed or generated, listed in SOURCES.md.

## Method
1. Get the concept approved first (storyboard doc); no render before approval.
2. Add/update `video.reels[n]` in content.json additively (python read-modify-write; don't clobber others' keys).
3. Work in a scratch copy (e.g. /tmp/<name>): `cp -r template /tmp/x && cd /tmp/x && npm ci`, then
   `node render-reel.mjs --client <id> --clients <RUN>/clients --assets <RUN>/assets --out <RUN>/creative/video-vN`. Never leave node_modules in templates/.
4. Design rules: photo above a persistent navy panel (seam y=1150); copy only in y 250–1580 (Reels UI zones); headline 800 weight 104–124px; slow Ken Burns (3–4%), clean cuts, one spring on the CTA; sun mark rises on the seam in scene 1; icons tinted via CSS mask; end card = mark + name, two-line tagline, subline, sunflower CTA button. No gradients, no emoji, silent unless licensed audio.
5. Verify: `ffprobe` → h264 1080x1920 30/1, nb_frames 450, duration 15.000000; extract a frame every 1s and LOOK at each (text overflow, safe zones, crop clutter such as toys/clutter, repeated shots, font fallback, awkward breaks). Fix and re-render until clean.
6. Deliver to `creative/video-vN/`: reel.mp4, poster.png, caption.txt, alt.txt, SOURCES.md, manifest.json (template version, sha256 of outputs + client JSON, exact command). Build a portable source ZIP (template + clients/<id>/{brand,content}.json + clients/<id>/assets (only files used) + README/SKILL, no node_modules/caches/secrets) and verify it from a fresh /tmp extraction: `npm ci && node render-reel.mjs --client <id>` then ffprobe.
7. Record approvals in `creative/APPROVALS.md` (who, date, file + sha256). Approved files stay unchanged; changes ship as a new version.

## Feedback → revise → re-render loop
1. Send the draft (MP4 + poster + caption + manifest) for feedback; state it is a DRAFT.
2. Capture each note verbatim in the reel's notes/manifest; map it to a data change (content.json scene/copy/crop) or a layout change (PhotoReel.tsx).
3. Revise, bump to `video-v(N+1)` (never overwrite an approved version), re-render, re-run step 5 checks, and re-send with a short "what changed" list.
4. Repeat until explicit approval; record it in APPROVALS.md. Uploading/publishing (incl. Zernio) needs a separate explicit instruction.

Lessons (v1): Plus Jakarta Sans 800 sets a loose full stop at display size, so the composition tucks it in (Kern). Load fonts via FontFace + delayRender. Avoid the living-room right edge (toys/bookshelf). Use explicit `headlineLines` for the end card.
