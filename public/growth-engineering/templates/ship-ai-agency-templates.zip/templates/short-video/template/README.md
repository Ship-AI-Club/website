# Short Video template · PhotoReel (Remotion 4.0.535)
Photo-led 9:16 reel driven entirely by client data. No client copy lives in `src/`.
Bundled font: Plus Jakarta Sans 400/600/800 woff2 in `src/fonts/` (SIL OFL 1.1, `src/fonts/OFL-LICENSE.txt`), loaded before every frame.

## Run (from this folder, relative paths only)
```
npm ci && node render-reel.mjs --client desert-shine
```
Output: `out/<client>/reel.mp4` (1080x1920, 30fps, h264 yuv420p, duration = last scene `to`, 15.0s for desert-shine) and `out/<client>/poster.png` (frame at `posterSec`).
Options: `--reel <id>` (default first of `video.reels`), `--clients <dir>` (default `./clients`), `--assets <dir>` (default `<clients>/<client>/assets`, else `<clients>/../assets`), `--out <dir>`.
Requires Node 20+. First run downloads Chrome Headless Shell (~100 MB) into node_modules.

## Inputs
- `clients/<id>/brand.json`: `business.name`, `tokens.colors.{navy,sky,sunflower,slate,white}` (falls back to primary/background/accent/secondary), `tokens.radius`, `logo.markOnDark`.
- `clients/<id>/content.json`: `services[]` (`id,name,icon,image`) and `video.reels[]` (`id, composition:"PhotoReel", posterSec, scenes[]`).
  Scene types: `photo` (`image, position, headline, eyebrow?, motion: push|pan|drift, sunRise?`), `services` (`serviceIds, labels, images[]`), `endcard` (`headlineLines, subline, ctaLabel`). `from`/`to` in seconds.
- `clients/<id>/assets/`: images, icons (currentColor SVG, tinted via mask), brand SVGs. Paths in JSON are relative to it.

## Design rules baked in
Copy sits between y=250 and y=1580 (Reels top ~250px / bottom ~340px UI). Photo above a persistent navy panel (seam y=1150); slow Ken Burns (3–4%), clean cuts, one spring on the CTA. No gradients, no emoji, silent (add audio only if licensed).

## Another client
Copy `clients/desert-shine` to `clients/<new-id>`, replace brand/content values and assets with approved copy and licensed images only, then `node render-reel.mjs --client <new-id>`.

## Feedback loop
Render → extract a frame every 1s (`ffmpeg -i out/<id>/reel.mp4 -vf fps=1 f%02d.png`) and inspect → send draft for feedback → edit only content.json/brand.json (or the composition for layout bugs) → re-render as v2 → re-verify ffprobe 1080x1920/15.0s. Never upload or publish without explicit approval.
Legacy text-only `Reel` composition is kept in `src/Reel.tsx`.
