// Portable renderer for the Short Video template. All paths are relative to this folder unless overridden.
// Usage: npm ci && node render-reel.mjs --client desert-shine [--reel video-v1] [--clients ./clients] [--assets <dir>] [--out ./out]
// Reads <clients>/<client>/brand.json + content.json (video.reels[] for PhotoReel). Assets: <clients>/<client>/assets, else <clients>/../assets.
import fs from "node:fs"; import path from "node:path"; import { fileURLToPath } from "node:url";
import { bundle } from "@remotion/bundler"; import { renderMedia, renderStill, selectComposition } from "@remotion/renderer";
const here = path.dirname(fileURLToPath(import.meta.url));
const arg = (k, d) => { const i = process.argv.indexOf(k); return i > -1 ? process.argv[i + 1] : d; };
const client = arg("--client", "desert-shine");
if (!/^[a-z0-9-]+$/.test(client)) throw new Error(`Bad client id "${client}"`);
const clientsDir = path.resolve(arg("--clients", path.join(here, "clients")));
const cdir = path.join(clientsDir, client);
const read = f => JSON.parse(fs.readFileSync(path.join(cdir, f), "utf8"));
const brand = read("brand.json"), content = read("content.json");
const assets = path.resolve(arg("--assets", fs.existsSync(path.join(cdir, "assets")) ? path.join(cdir, "assets") : path.join(clientsDir, "..", "assets")));
const out = path.resolve(arg("--out", path.join(here, "out", client)));
const reelId = arg("--reel", content.video?.reels?.[0]?.id);
const reel = content.video?.reels?.find(r => r.id === reelId);
if (!reel) throw new Error(`content.json has no video.reels entry "${reelId}"`);
const c = brand.tokens.colors;
const inputProps = {
  name: brand.business.name, radius: brand.tokens.radius ?? 6,
  colors: { navy: c.navy ?? c.primary, sky: c.sky ?? c.background, sunflower: c.sunflower ?? c.accent, slate: c.slate ?? c.secondary, white: c.white ?? "#FFFFFF" },
  mark: brand.logo.mark, markOnDark: brand.logo.markOnDark,
  services: content.services.map(s => ({ id: s.id, name: s.name, icon: s.icon, image: s.image })),
  scenes: reel.scenes,
};
for (const s of reel.scenes) if (s.image && !fs.existsSync(path.join(assets, s.image))) throw new Error(`Missing asset ${s.image} in ${assets}`);
fs.mkdirSync(out, { recursive: true });
const serveUrl = await bundle({ entryPoint: path.join(here, "src/index.ts"), publicDir: assets });
const composition = await selectComposition({ serveUrl, id: reel.composition ?? "PhotoReel", inputProps });
const videoName = arg("--name", "reel.mp4");
if (!/^[a-zA-Z0-9_-]+\.mp4$/.test(videoName)) throw new Error("--name must be an MP4 filename");
const mp4 = path.join(out, videoName);
await renderMedia({ composition, serveUrl, codec: "h264", crf: 16, pixelFormat: "yuv420p", outputLocation: mp4, inputProps });
const posterSec = reel.posterSec ?? 12.8;
await renderStill({ composition, serveUrl, frame: Math.round(posterSec * composition.fps), output: path.join(out, "poster.png"), inputProps });
console.log(`[${client}/${reel.id}] wrote ${mp4} and poster.png (${composition.width}x${composition.height}, ${composition.durationInFrames}f @${composition.fps})`);
