import React from "react";
import { AbsoluteFill, Img, delayRender, continueRender, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig, Easing } from "remotion";
import f400 from "./fonts/plus-jakarta-sans-latin-400-normal.woff2";
import f600 from "./fonts/plus-jakarta-sans-latin-600-normal.woff2";
import f800 from "./fonts/plus-jakarta-sans-latin-800-normal.woff2";

// PhotoReel: generic photo-led 9:16 reel. NO client copy lives here; everything arrives as inputProps
// built by render-reel.mjs from clients/<id>/brand.json + content.json (video.reels[n]).
// Asset paths (img/..., icons/..., brand/...) resolve against the client's assets folder (Remotion publicDir).

export type Scene = {
  id: string; type: "photo" | "services" | "endcard"; from: number; to: number;
  image?: string; position?: string; eyebrow?: string; headline: string; headlineLines?: string[]; motion?: "push" | "pan" | "drift"; sunRise?: boolean;
  serviceIds?: string[]; labels?: string[]; images?: { src: string; position?: string }[]; ctaLabel?: string; subline?: string;
};
export type Service = { id: string; name: string; icon: string; image: { src: string; position?: string } };
export type PhotoReelProps = {
  name: string;
  colors: { navy: string; sky: string; sunflower: string; slate: string; white: string };
  radius: number; mark: string; markOnDark: string; scenes: Scene[]; services: Service[];
};

const FONT = "PJS";

// Reels safe zone: keep copy between y=250 and y=1580 (bottom 340px is UI).
const W = 1080, H = 1920, SEAM = 1150, PAD = 88;
// Optical kerning: Plus Jakarta Sans 800 sets a loose full stop at display sizes; tuck it in.
const Kern: React.FC<{ text: string }> = ({ text }) => <>{text.split(/(\.)/).map((x, i) => x === "." ? <span key={i} style={{ marginLeft: "-0.07em" }}>.</span> : x)}</>;
const ease = Easing.bezier(0.22, 1, 0.36, 1);

const KenBurns: React.FC<{ src: string; position?: string; motion?: Scene["motion"]; dur: number; h?: number }> = ({ src, position = "50% 50%", motion = "push", dur, h = H }) => {
  const f = useCurrentFrame();
  const p = interpolate(f, [0, dur], [0, 1], { extrapolateRight: "clamp" });
  const scale = motion === "push" ? 1.04 + 0.04 * p : motion === "pan" ? 1.12 : 1.06 + 0.02 * p;
  const tx = motion === "pan" ? interpolate(p, [0, 1], [30, -30]) : motion === "drift" ? interpolate(p, [0, 1], [-12, 12]) : 0;
  return <div style={{ position: "absolute", left: 0, top: 0, width: W, height: h, overflow: "hidden" }}>
    <Img src={staticFile(src)} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: position, transform: `scale(${scale}) translateX(${tx}px)` }} />
  </div>;
};

const Rise: React.FC<{ delay?: number; children: React.ReactNode; style?: React.CSSProperties }> = ({ delay = 0, children, style }) => {
  const f = useCurrentFrame();
  const p = interpolate(f - delay, [0, 14], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: ease });
  return <div style={{ opacity: p, transform: `translateY(${(1 - p) * 28}px)`, ...style }}>{children}</div>;
};

const Icon: React.FC<{ src: string; color: string; size: number }> = ({ src, color, size }) =>
  <div style={{ width: size, height: size, backgroundColor: color, WebkitMaskImage: `url(${staticFile(src)})`, WebkitMaskSize: "contain", WebkitMaskRepeat: "no-repeat", WebkitMaskPosition: "center" }} />;

// Photo top, navy panel below the seam; the panel persists so cuts feel continuous.
const Panel: React.FC<{ c: PhotoReelProps["colors"]; slide?: boolean }> = ({ c, slide }) => {
  const f = useCurrentFrame();
  const y = slide ? interpolate(f, [0, 16], [120, 0], { extrapolateRight: "clamp", easing: ease }) : 0;
  return <div style={{ position: "absolute", left: 0, top: SEAM + y, width: W, height: H - SEAM, background: c.navy }} />;
};

const PhotoScene: React.FC<{ s: Scene; p: PhotoReelProps; dur: number }> = ({ s, p, dur }) => {
  const c = p.colors; const f = useCurrentFrame(); const { fps } = useVideoConfig();
  const sun = spring({ frame: f - 4, fps, config: { damping: 200 }, durationInFrames: 30 });
  return <AbsoluteFill>
    <KenBurns src={s.image!} position={s.position} motion={s.motion} dur={dur} h={SEAM + 40} />
    <Panel c={c} slide={s.motion === "pan"} />
    {s.sunRise && <div style={{ position: "absolute", left: PAD - 10, top: SEAM - 66 + (1 - sun) * 90, opacity: sun, width: 132, height: 132, borderRadius: 999, background: c.navy, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <Img src={staticFile(p.markOnDark)} style={{ width: 112, height: 112 }} /></div>}
    <div style={{ position: "absolute", left: PAD, right: PAD, top: SEAM + (s.sunRise ? 110 : 92) }}>
      {s.eyebrow && <Rise delay={6}><div style={{ fontWeight: 600, fontSize: 36, letterSpacing: 1, color: c.sunflower, marginBottom: 22 }}>{s.eyebrow}</div></Rise>}
      <Rise delay={s.eyebrow ? 10 : 6}><div style={{ fontWeight: 800, fontSize: s.headline.length > 18 ? 104 : 124, lineHeight: 1.04, letterSpacing: "-0.02em", color: c.white }}><Kern text={s.headline} /></div></Rise>
      <Rise delay={16}><div style={{ marginTop: 34, width: 120, height: 10, borderRadius: 5, background: c.sunflower }} /></Rise>
    </div>
  </AbsoluteFill>;
};

const ServicesScene: React.FC<{ s: Scene; p: PhotoReelProps; dur: number }> = ({ s, p, dur }) => {
  const c = p.colors; const f = useCurrentFrame();
  const ids = s.serviceIds ?? []; const per = dur / ids.length;
  const i = Math.min(ids.length - 1, Math.floor(f / per));
  const svc = p.services.find(x => x.id === ids[i])!;
  const local = f - i * per;
  return <AbsoluteFill>
    {ids.map((id, k) => { const sv = p.services.find(x => x.id === id)!; return k === i &&
      <Sequence key={id} from={Math.round(k * per)} durationInFrames={Math.round(per)} layout="none">
        <KenBurns src={s.images?.[k]?.src ?? sv.image.src} position={s.images?.[k]?.position ?? sv.image.position} motion="drift" dur={per} h={SEAM + 40} />
      </Sequence>; })}
    <Panel c={c} />
    <div style={{ position: "absolute", left: PAD, right: PAD, top: SEAM + 92 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 34 }}>
        <div key={i} style={{ width: 132, height: 132, borderRadius: p.radius * 3, background: c.sunflower, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${interpolate(local, [0, 10], [0.85, 1], { extrapolateRight: "clamp", easing: ease })})` }}>
          <Icon src={svc.icon} color={c.navy} size={84} /></div>
        <div style={{ fontWeight: 800, fontSize: 92, letterSpacing: "-0.015em", color: c.white, opacity: interpolate(local, [0, 8], [0, 1], { extrapolateRight: "clamp" }) }}>{s.labels?.[i] ?? svc.name}</div>
      </div>
      <div style={{ display: "flex", gap: 20, marginTop: 64 }}>
        {(s.labels ?? []).map((l, k) => <div key={l} style={{ fontWeight: 600, fontSize: 38, padding: "14px 28px", borderRadius: 999, border: `3px solid ${k === i ? c.sunflower : "rgba(255,255,255,0.35)"}`, background: k === i ? c.sunflower : "transparent", color: k === i ? c.navy : c.white }}>{l}</div>)}
      </div>
    </div>
  </AbsoluteFill>;
};

const EndCard: React.FC<{ s: Scene; p: PhotoReelProps }> = ({ s, p }) => {
  const c = p.colors; const f = useCurrentFrame(); const { fps } = useVideoConfig();
  const btn = spring({ frame: f - 18, fps, config: { damping: 14, stiffness: 120 } });
  return <AbsoluteFill style={{ background: c.navy, alignItems: "center", justifyContent: "center" }}>
    <div style={{ position: "absolute", top: 520, left: 0, right: 0, display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", padding: `0 ${PAD}px` }}>
      <Rise><div style={{ display: "flex", alignItems: "center", gap: 26 }}>
        <Img src={staticFile(p.markOnDark)} style={{ width: 132, height: 132 }} />
        <div style={{ fontWeight: 800, fontSize: 84, letterSpacing: "-0.015em", color: c.white }}>{p.name}</div></div></Rise>
      <Rise delay={6}><div style={{ marginTop: 70, fontWeight: 800, fontSize: 70, lineHeight: 1.1, letterSpacing: "-0.015em", color: c.white }}>{(s.headlineLines ?? [s.headline]).map(l => <div key={l}><Kern text={l} /></div>)}</div></Rise>
      {s.subline && <Rise delay={10}><div style={{ marginTop: 34, fontWeight: 400, fontSize: 38, lineHeight: 1.35, color: c.sky, maxWidth: 820 }}>{s.subline}</div></Rise>}
      <div style={{ marginTop: 90, transform: `scale(${0.6 + 0.4 * btn})`, opacity: Math.min(1, btn * 1.5), background: c.sunflower, color: c.navy, fontWeight: 800, fontSize: 52, padding: "38px 64px", borderRadius: p.radius * 2 }}>{s.ctaLabel}</div>
    </div>
  </AbsoluteFill>;
};

// Load bundled fonts before any frame is captured (no system-font fallback in renders).
const fontHandle = typeof window !== "undefined" ? delayRender("Plus Jakarta Sans") : 0;
if (typeof window !== "undefined") Promise.all([[400, f400], [600, f600], [800, f800]].map(([w, u]) =>
  new FontFace(FONT, `url(${u}) format('woff2')`, { weight: String(w) }).load().then(ff => document.fonts.add(ff))))
  .then(() => continueRender(fontHandle)).catch(e => { console.error(e); continueRender(fontHandle); });

export const PhotoReel: React.FC<PhotoReelProps> = (p) => {
  const { fps } = useVideoConfig();
  return <AbsoluteFill style={{ fontFamily: `${FONT}, system-ui, sans-serif`, background: p.colors.navy }}>
    {p.scenes.map(s => { const from = Math.round(s.from * fps), dur = Math.round((s.to - s.from) * fps);
      return <Sequence key={s.id} from={from} durationInFrames={dur}>
        {s.type === "photo" ? <PhotoScene s={s} p={p} dur={dur} /> : s.type === "services" ? <ServicesScene s={s} p={p} dur={dur} /> : <EndCard s={s} p={p} />}
      </Sequence>; })}
  </AbsoluteFill>;
};
