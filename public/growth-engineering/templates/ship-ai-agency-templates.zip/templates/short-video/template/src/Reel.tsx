import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring } from "remotion";
// Generic: captions + tokens arrive as inputProps from clients/<client>/content.json (reel.captions) + brand.json.
export type Caption = { from: number; to: number; text: string };
export type ReelProps = { brand: { business: { name: string }; tokens: { colors: { primary: string; secondary: string; background: string; text: string }; font: string } }; captions: Caption[] };
export const Reel: React.FC<ReelProps> = ({ brand, captions }) => {
  const c = brand.tokens.colors;
  const f = useCurrentFrame(); const { fps } = useVideoConfig(); const t = f / fps;
  const cap = captions.find(x => t >= x.from && t < x.to) ?? captions[captions.length - 1];
  const isCta = cap === captions[captions.length - 1]; // last caption = CTA card
  const s = spring({ frame: f - Math.round(cap.from * fps), fps });
  return (<AbsoluteFill style={{ background: isCta ? c.primary : c.background, fontFamily: brand.tokens.font, alignItems: "center", justifyContent: "center", padding: 80 }}>
    <div style={{ position: "absolute", top: 140, fontSize: 64, fontWeight: 900, color: isCta ? "#fff" : c.secondary }}>{brand.business.name}</div>
    <div style={{ fontSize: 96, fontWeight: 900, textAlign: "center", lineHeight: 1.1, maxWidth: 920, color: isCta ? "#fff" : c.text, transform: `scale(${0.9 + 0.1 * s})` }}>{cap.text}</div>
  </AbsoluteFill>);
};
