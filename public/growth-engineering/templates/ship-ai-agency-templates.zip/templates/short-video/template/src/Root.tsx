import { Composition } from "remotion";
import { Reel, type ReelProps } from "./Reel";
import { PhotoReel, type PhotoReelProps } from "./PhotoReel";
// Placeholder defaults only (Studio preview). render-reel.mjs passes the client's real data as inputProps.
const placeholder: ReelProps = { brand: { business: { name: "Client Name" }, tokens: { colors: { primary: "#333", secondary: "#666", background: "#fff", text: "#111" }, font: "system-ui" } }, captions: [{ from: 0, to: 11, text: "Caption" }, { from: 11, to: 15, text: "Call to action" }] };
const photoPlaceholder: PhotoReelProps = { name: "Client Name", colors: { navy: "#222", sky: "#eee", sunflower: "#fc0", slate: "#666", white: "#fff" }, radius: 6, mark: "", markOnDark: "", services: [], scenes: [] };
export const Root = () => <>
  <Composition id="PhotoReel" component={PhotoReel} durationInFrames={450} fps={30} width={1080} height={1920} defaultProps={photoPlaceholder}
    calculateMetadata={({ props }) => { const end = Math.max(15, ...props.scenes.map(s => s.to)); return { durationInFrames: Math.round(end * 30) }; }} />
  <Composition id="Reel" component={Reel} durationInFrames={450} fps={30} width={1080} height={1920} defaultProps={placeholder} />
</>;
