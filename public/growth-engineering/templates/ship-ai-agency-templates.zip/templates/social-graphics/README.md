# Ship AI · social-graphics

Read `BUILD-YOUR-AI-MARKETING-TEAM.md` at kit root. This template is the actual Grok Bot source used in the improved Desert Shine demo. Shared copy and assets live at kit root in `clients/` and `assets/`.

Run from kit root:
```bash
cd templates/social-graphics/template && npm ci && node render-creative.mjs --project ../../.. --remotion . --client desert-shine --id social-v1 --out ../../../out --name social-v1.png
```

Node 20+ and npm required. Remotion downloads a browser on first render. Fonts and photo licenses are bundled. Render one static first and repeat feedback until approved. Research and approve the video concept before rendering; review the full video and caption afterward. Neither renderer uploads or posts.

The `template/README.md` documents composition inputs and flags; use the explicit shared paths above in this kit. For another client, replace the client JSON, logo and licensed photos.
