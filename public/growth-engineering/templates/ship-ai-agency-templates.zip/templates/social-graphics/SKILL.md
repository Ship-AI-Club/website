---
name: Ship AI Demo · Client social stills
description: >-
  Render 3 static social PNGs (1080x1350, optional 1080x1080) for an agency
  client from its canonical content.json/brand.json using Remotion renderStill.
  Use when asked for client social graphics.
---
# Client social stills (Remotion renderStill)
Input: `client` (default `desert-shine`). Run from the template folder (holds `clients/`, `assets/`, `src/`); no absolute paths.

## Canonical inputs (single source of truth)
- Tokens/identity/logo paths: `clients/<client>/brand.json` (`tokens.colors`, `tokens.font`, `tokens.radius`, `logo.lockupOnDark`, `logo.markOnDark`).
- Copy: `clients/<client>/content.json`. Photo-led posts live in `socialCreatives[]` (`id, composition, serviceId, eyebrow, headlineLines[], body, ctaLabel, ctaHref, caption, alt`); the image comes from the referenced `services[].image` (`src, alt, position`). Legacy text posts: `socialMessages[]`. Add entries additively; never rewrite existing messaging.
- Assets: `assets/` (img/, brand/). SVG logos are inlined so live-text lockups use the bundled font.
- Fonts: bundled in `src/fonts/` (Plus Jakarta Sans 400/600/800, OFL). No CDN.
- RULE: template code holds no client copy, colors or paths. Facts only from content.json: no invented reviews, prices, guarantees, contact details. Agency tagline never in client creative.

## Method (photo-led 4:5)
- Layout `SocialPhoto4x5`: full-bleed licensed photo on top (~56%), solid navy brand panel below, sun mark seated on the seam, sunflower eyebrow rule, big tight headline (800), one-line body, sunflower CTA button, white lockup. No text on photos, no gradients, no emoji, no card soup.
- One benefit headline, ONE service, the quote CTA.
- Render: `npm ci && node render-creative.mjs --client <client> --id <creative-id>   # from the template folder; writes out/post.png`
- Inspect the PNG at full size and zoomed into the headline: widows, kerning around punctuation, crop clutter, contrast, CTA legibility, logo size. Fix in template (generic) or client data (copy/position), re-render.
- Package `creative/<id>/`: post.png, caption.txt, alt.txt, SOURCES.md (photo source+license from assets/SOURCES.md), manifest.json (inputs+sha256, composition, command, dimensions, output hashes); zip as `creative/<client>-<id>.zip`. Verify size with `ffprobe -v error -show_entries stream=width,height -of csv=p=0 post.png`.

## Feedback loop (required)
1. Render ONE draft (one 4:5).
2. Show it to the user with caption + alt; ask what to change in message or design.
3. Revise client data (content.json/brand.json) or the generic template.
4. Re-render, re-verify (dimensions, inspection, hashes in manifest), show again.
5. Repeat until the user explicitly approves that exact version.
6. Only then render the rest (other services, 1x1, `node render-stills.mjs`). Do not re-render approved, unchanged media.
Never upload, post or schedule. Hand paths to the Campaign Manager.
