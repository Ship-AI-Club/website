# Desert Shine · Social Graphics template (portable source v1)
A photo-led 4:5 social creative (1080x1350) rendered with Remotion. It runs from this folder alone, with no absolute paths. All copy, colors and asset paths come from `clients/<id>/brand.json` and `content.json`. The template code holds no client copy.

## Requirements
Node 20+ and npm. On the first render, Remotion downloads its headless Chrome (needs network once; cached under node_modules).

## Run (from this folder)
```
npm ci && node render-creative.mjs --client desert-shine
```
Output: `out/post.png` (1080x1350). Options: `--id <socialCreatives id>` (default: first), `--out <dir>`, `--name <file.png>`, `--assets <dir>` (default `assets/`).
Legacy text-only set: `node render-stills.mjs --client desert-shine --no-square` → `out/post-{1,2,3}-Social4x5.png`.

## Layout of this folder
- `render-creative.mjs`, `render-stills.mjs`, `lib.mjs`: render scripts (resolve deps from ./node_modules and clients/ next to them).
- `src/`: Remotion compositions (`SocialPhoto4x5`, `Social4x5`, `Social1x1`), `fonts.ts`, `fonts/` (Plus Jakarta Sans 400/600/800 woff2 + OFL-LICENSE.txt).
- `clients/desert-shine/`: brand.json (tokens, logo paths) and content.json (copy; `socialCreatives[]`, `services[].image`).
- `assets/`: the photo and logo SVGs referenced by the JSON, with `assets/SOURCES.md` for licenses.

## Inputs used by SocialPhoto4x5
brand.json: `tokens.colors.{navy,sky,sunflower,white}`, `tokens.font`, `tokens.radius`, `logo.{lockupOnDark,markOnDark}`.
content.json: `socialCreatives[]` (`id, composition, serviceId, eyebrow, headlineLines, body, ctaLabel, ctaHref, caption, alt`) plus the referenced `services[].image` (`src, alt, position`).

## Another client
Copy `clients/desert-shine/` to `clients/<new-id>/`, replace every value with approved copy only (no invented reviews, prices or guarantees), put that client's licensed photo and logos in `assets/`, then run `node render-creative.mjs --client <new-id>`.

## Feedback loop (required)
1. Render ONE 4:5 draft. 2. Show it to the user with caption and alt text, and ask for feedback. 3. Revise the client data or the generic template. 4. Re-render and re-verify (1080x1350, visual inspection). 5. Repeat until the user explicitly approves that version. 6. Only then render the rest. Never upload or post.
