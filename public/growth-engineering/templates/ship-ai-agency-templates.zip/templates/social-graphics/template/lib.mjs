// Shared loader: resolves Remotion deps from the existing remotion/ install and client JSON from clients/<client>/.
// No client copy lives in this template; everything comes from brand.json + content.json passed as inputProps.
import fs from "node:fs"; import path from "node:path"; import { createRequire } from "node:module"; import { fileURLToPath, pathToFileURL } from "node:url";
export const here = path.dirname(fileURLToPath(import.meta.url));
export const arg = (k, d) => { const i = process.argv.indexOf(k); return i > -1 ? process.argv[i + 1] : d; };
// Portable defaults: a standalone kit folder (clients/ next to this file, deps in ./node_modules) needs no flags.
// Inside the full agency kit it falls back to <kit-root>/ and <kit-root>/remotion. Flags/env override both.
const firstWith = (cands, rel) => cands.find(d => fs.existsSync(path.join(d, rel))) ?? cands[cands.length - 1];
export const PROJECT = path.resolve(arg("--project", process.env.SHIP_AI_PROJECT ?? firstWith([here, path.join(here, "../../..")], "clients")));
export const REMOTION = path.resolve(arg("--remotion", process.env.SHIP_AI_REMOTION ?? firstWith([here, PROJECT, path.join(PROJECT, "remotion")], "node_modules/remotion")));
export const CLIENT = arg("--client", process.env.CLIENT ?? "desert-shine");
export const OUT = path.resolve(arg("--out", path.join(PROJECT, "out")));
const req = createRequire(path.join(REMOTION, "package.json"));
export const imp = m => import(pathToFileURL(req.resolve(m)).href);
export function loadClient(id = CLIENT) {
  if (!/^[a-z0-9-]+$/.test(id) || id.startsWith("_")) throw new Error(`Bad client id "${id}"`);
  const d = path.join(PROJECT, "clients", id);
  for (const f of ["brand.json", "content.json"]) if (!fs.existsSync(path.join(d, f))) throw new Error(`Missing ${d}/${f} (copy clients/_template/)`);
  const read = f => JSON.parse(fs.readFileSync(path.join(d, f), "utf8"));
  return { brand: read("brand.json"), content: read("content.json") };
}
export async function bundleTemplate(opts = {}) {
  const { bundle } = await imp("@remotion/bundler");
  return bundle({ entryPoint: path.join(here, "src/index.ts"), ...opts,
    webpackOverride: c => ({ ...c, resolve: { ...c.resolve, modules: [path.join(REMOTION, "node_modules"), "node_modules"] } }) });
}
