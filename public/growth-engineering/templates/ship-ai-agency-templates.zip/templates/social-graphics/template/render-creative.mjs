// Renders ONE photo-led creative from content.json socialCreatives[] (draft for feedback).
// Usage: node render-creative.mjs --project <run> --client <id> --id social-v1 [--assets <dir>] [--out <dir>]
// Copy/colors from clients/<id>/{brand,content}.json; image + logo paths are relative to --assets (default <project>/assets).
import path from "node:path"; import fs from "node:fs";
import { imp, loadClient, bundleTemplate, CLIENT, OUT, PROJECT, arg } from "./lib.mjs";
const { renderStill, selectComposition } = await imp("@remotion/renderer");
const { brand, content } = loadClient();
const ASSETS = path.resolve(arg("--assets", path.join(PROJECT, "assets")));
const id = arg("--id", content.socialCreatives?.[0]?.id);
const post = (content.socialCreatives ?? []).find(p => p.id === id);
if (!post) throw new Error(`content.json socialCreatives has no "${id}"`);
const svc = content.services.find(s => s.id === post.serviceId);
if (!svc?.image) throw new Error(`service "${post.serviceId}" has no image in content.json`);
for (const f of [svc.image.src, brand.logo.lockupOnDark, brand.logo.markOnDark]) if (!fs.existsSync(path.join(ASSETS, f))) throw new Error(`Missing asset ${ASSETS}/${f}`);
const svg = f => fs.readFileSync(path.join(ASSETS, f), "utf8"); // inlined so live-text lockups use the bundled font
const inputProps = { brand, post, image: svc.image, lockupSvg: svg(brand.logo.lockupOnDark), markSvg: svg(brand.logo.markOnDark) };
fs.mkdirSync(OUT, { recursive: true });
const serveUrl = await bundleTemplate({ publicDir: ASSETS });
const composition = await selectComposition({ serveUrl, id: post.composition, inputProps });
const output = path.join(OUT, arg("--name", "post.png"));
await renderStill({ composition, serveUrl, output, inputProps });
console.log(`[${CLIENT}] ${post.composition} ${composition.width}x${composition.height} wrote ${output}`);
