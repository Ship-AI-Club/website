// Renders every content.json socialMessages entry as Social4x5 (1080x1350) and Social1x1 (1080x1080) PNGs.
// Messages are read from clients/<client>/content.json — never duplicated here.
// Usage: node render-stills.mjs [--client desert-shine] [--out <dir>] [--no-square]
import path from "node:path"; import fs from "node:fs";
import { imp, loadClient, bundleTemplate, CLIENT, OUT } from "./lib.mjs";
const { renderStill, selectComposition } = await imp("@remotion/renderer");
const { brand, content } = loadClient();
const ids = process.argv.includes("--no-square") ? ["Social4x5"] : ["Social4x5", "Social1x1"];
fs.mkdirSync(OUT, { recursive: true });
const serveUrl = await bundleTemplate();
for (const id of ids) for (const msg of content.socialMessages) {
  const inputProps = { brand, cta: content.cta.label, msg };
  const composition = await selectComposition({ serveUrl, id, inputProps });
  const output = path.join(OUT, `${msg.id}-${id}.png`);
  await renderStill({ composition, serveUrl, output, inputProps });
  console.log(`[${CLIENT}] wrote`, output);
}
