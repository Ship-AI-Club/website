import { Still } from "remotion";
import { SocialStill } from "./SocialStill";
import { SocialPhoto } from "./SocialPhoto";
import type { StillProps, PhotoProps } from "./types";
// Placeholder defaults only (for Studio preview). Real values are passed as inputProps by render-stills.mjs.
const pb = { business: { name: "Client Name" }, tokens: { colors: { primary: "#333", secondary: "#666", background: "#fff", text: "#111", navy: "#222", sky: "#eee", sunflower: "#fc0", white: "#fff" }, font: "system-ui", radius: 6 } };
const placeholder: StillProps = { brand: pb, cta: "Call to action", msg: { id: "post-1", headline: "Headline", body: "Body copy" } };
const photo: PhotoProps = { brand: pb, post: { id: "x", composition: "SocialPhoto4x5", serviceId: "x", eyebrow: "Eyebrow", headlineLines: ["Headline"], body: "Body", ctaLabel: "CTA" }, image: { src: "placeholder.jpg", width: 1, height: 1, alt: "", position: "50% 50%" }, lockupSvg: "<svg/>", markSvg: "<svg/>" };
export const Root = () => (<>
  <Still id="Social4x5" component={SocialStill} width={1080} height={1350} defaultProps={placeholder} />
  <Still id="Social1x1" component={SocialStill} width={1080} height={1080} defaultProps={placeholder} />
  <Still id="SocialPhoto4x5" component={SocialPhoto} width={1080} height={1350} defaultProps={photo} />
</>);
