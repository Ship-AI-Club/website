import { AbsoluteFill, Img, staticFile } from "remotion";
import "./fonts";
import type { PhotoProps } from "./types";
// Generic photo-led layout: full-bleed photo on top, solid brand panel below (no text on the photo,
// no gradients). Every string, color and asset path arrives as inputProps from clients/<client>/*.json.
export const SocialPhoto: React.FC<PhotoProps> = ({ brand, post, image, lockupSvg, markSvg }) => {
  const c = brand.tokens.colors; const r = brand.tokens.radius;
  const W = 1080, PH = 760, PAD = 84;
  return (
    <AbsoluteFill style={{ background: c.navy, fontFamily: brand.tokens.font, color: c.white, fontKerning: "normal", textRendering: "optimizeLegibility", fontFeatureSettings: "\"kern\" 1" }}>
      <div style={{ position: "absolute", left: 0, top: 0, width: W, height: PH, overflow: "hidden" }}>
        <Img src={staticFile(image.src)} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: image.position }} />
      </div>
      {/* sun mark seated on the seam between photo and panel */}
      <div style={{ position: "absolute", left: W - PAD - 132, top: PH - 66, width: 132, height: 132, borderRadius: 66, background: c.navy,
        display: "flex", alignItems: "center", justifyContent: "center" }}
        dangerouslySetInnerHTML={{ __html: markSvg.replace(/width="\d+" height="\d+"/, 'width="104" height="104"') }} />
      <div style={{ position: "absolute", left: PAD, right: PAD, top: PH + 64, bottom: 72, display: "flex", flexDirection: "column" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, fontSize: 26, fontWeight: 600, letterSpacing: 2.5, textTransform: "uppercase", color: c.sunflower }}>
          <span style={{ width: 40, height: 4, background: c.sunflower, display: "inline-block" }} />{post.eyebrow}
        </div>
        <div style={{ marginTop: 26, fontSize: 88, fontWeight: 800, lineHeight: 1.02, letterSpacing: -1.2 }}>
          {post.headlineLines.map(l => <div key={l}>{/[.!?]$/.test(l) ? <>{l.slice(0, -1)}<span style={{ marginLeft: "-0.07em" }}>{l.slice(-1)}</span></> : l}</div>)}{/* optical: tighten wide sidebearing before end punctuation at display size */}
        </div>
        <div style={{ marginTop: 24, fontSize: 32, lineHeight: 1.4, color: c.sky, opacity: 0.92, maxWidth: 900 }}>{post.body}</div>
        <div style={{ flex: 1 }} />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ background: c.sunflower, color: c.navy, fontSize: 32, fontWeight: 800, padding: "24px 36px", borderRadius: r }}>{post.ctaLabel}&nbsp;&nbsp;→</div>
          <div style={{ height: 52 }} dangerouslySetInnerHTML={{ __html: lockupSvg.replace(/width="\d+" height="\d+"/, 'width="244" height="52"') }} />
        </div>
      </div>
    </AbsoluteFill>);
};
