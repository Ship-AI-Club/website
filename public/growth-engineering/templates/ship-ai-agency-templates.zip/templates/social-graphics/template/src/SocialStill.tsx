import { AbsoluteFill } from "remotion";
import type { StillProps } from "./types";
// Generic: all text/tokens arrive as inputProps built from clients/<client>/brand.json + content.json.
export const SocialStill: React.FC<StillProps> = ({ brand, cta, msg }) => {
  const c = brand.tokens.colors;
  return (
  <AbsoluteFill style={{ background: c.background, fontFamily: brand.tokens.font, padding: 90, justifyContent: "space-between" }}>
    <div style={{ fontSize: 44, fontWeight: 800, color: c.secondary }}>{brand.business.name}</div>
    <div><div style={{ fontSize: 110, fontWeight: 900, color: c.text, lineHeight: 1.05 }}>{msg.headline}</div>
      <div style={{ fontSize: 48, color: c.text, marginTop: 30 }}>{msg.body}</div></div>
    <div style={{ background: c.primary, color: "#fff", fontSize: 46, fontWeight: 800, padding: "28px 40px", borderRadius: brand.tokens.radius, alignSelf: "flex-start" }}>{cta}</div>
  </AbsoluteFill>);
};
