// Bundled, self-hosted Plus Jakarta Sans (OFL 1.1, see fonts/OFL-LICENSE.txt). No CDN.
import { continueRender, delayRender } from "remotion";
import f400 from "./fonts/plus-jakarta-sans-latin-400-normal.woff2";
import f600 from "./fonts/plus-jakarta-sans-latin-600-normal.woff2";
import f800 from "./fonts/plus-jakarta-sans-latin-800-normal.woff2";
const h = delayRender("bundled fonts");
Promise.all(([[f400, "400"], [f600, "600"], [f800, "800"]] as const).map(([u, w]) => {
  const ff = new FontFace("Plus Jakarta Sans", `url(${u}) format("woff2")`, { weight: w });
  return ff.load().then(x => { (document.fonts as any).add(x); });
})).then(() => continueRender(h)).catch(e => { console.error(e); continueRender(h); });
