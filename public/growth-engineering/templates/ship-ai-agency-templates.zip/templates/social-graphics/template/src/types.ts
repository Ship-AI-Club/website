export type Brand = { business: { name: string }; tokens: { colors: Record<string, string> & { primary: string; secondary: string; background: string; text: string }; font: string; radius: number } };
export type SocialMessage = { id: string; headline: string; body: string };
export type StillProps = { brand: Brand; cta: string; msg: SocialMessage };
// Photo-led creative (content.json socialCreatives[]); image comes from the referenced service.
export type SocialCreative = { id: string; composition: string; serviceId: string; eyebrow: string; headlineLines: string[]; body: string; ctaLabel: string; ctaHref?: string; caption?: string; alt?: string };
export type ImageRef = { src: string; width: number; height: number; alt: string; position: string };
export type PhotoProps = { brand: Brand; post: SocialCreative; image: ImageRef; lockupSvg: string; markSvg: string };
