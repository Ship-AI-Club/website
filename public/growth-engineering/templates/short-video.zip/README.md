# Ship AI · short-video

A reusable agency template with fictional Desert Shine reference output. Unzip into one folder; preserve its structure. Requires Node 20+ and npm. Read `BUILD-YOUR-AI-MARKETING-TEAM.md`, then `templates/short-video/README.md` and `SKILL.md`. The full workflow sequences the site, static feedback loop, Facebook ad research, video feedback loop, and exact-destination Zernio handoff. `<kit-root>` means the extracted folder.

Run from kit root:
```bash
cd templates/short-video/template && npm ci && node render-reel.mjs --clients ../../../clients --assets ../../../assets --client desert-shine --reel video-v1 --out ../../../out --name video-v1.mp4
```

The workflow exports local NOT_SENT requests and remains unapproved. It has no network sender. The website quote form is demo-only. Full kit and bot imports: https://www.shipai.club/programs/zero-to-launch/growth-engineering/deck
