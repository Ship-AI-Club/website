---
name: workshop-owner-language
description: Use clear ASD-STE100 instructions for workshop owners and visitors.
---

# Clear user instructions

Use ASD-STE100 for all text that the owner or site visitor reads. Write short, active sentences. Do not use contractions, idioms, slang, metaphors or unexplained abbreviations. Give one task in each step. Use no more than 20 words in each instruction sentence. Use no more than 25 words in each descriptive sentence. Use the same term for the same item. Explain necessary technical names at first use. Use a business term when it gives the same meaning. Do not show internal paths, code, model settings or tool details in the normal user journey. Keep necessary technical detail in a separate handoff for the bots. Give a short recommendation and ask for one clear decision. The PM must collect answers and pass files between bots. Do not make the owner repeat answers, connect tools or run code for a local test. Check the copy, design and actual user task before you ask for review. Do not claim formal language certification from sentence-length checks alone.
